import { defineConfig } from 'vite'
import { fileURLToPath } from 'node:url'
export default defineConfig({
  root: fileURLToPath(new URL('.', import.meta.url)),
  server: { proxy: { '/api': {target:'http://localhost:3000', changeOrigin:true} } },
  build: { outDir:'dist' }
})
