import express from 'express'
import 'dotenv/config'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const app = express()
app.disable('x-powered-by')
app.use(express.json({limit:'110kb'}))
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const W = 800, H = 560
const MODEL = process.env.OPENAI_MODEL || 'gpt-4.1-mini'
const requests = new Map()

app.get('/api/health', (_req,res)=>res.json({ok:true,aiConfigured:Boolean(process.env.OPENAI_API_KEY),model:MODEL}))

function validateOriginal(strokes){
 if(!Array.isArray(strokes) || strokes.length!==2)return '请先画好恰好两笔'
 let total=0
 for(const s of strokes){
  if(!s || typeof s.c!=='string' || !/^#[a-f\d]{6}$/i.test(s.c) || !Array.isArray(s.p) || s.p.length<1 || s.p.length>900)return '原始笔画格式不正确'
  total+=s.p.length
  if(!s.p.every(p=>Array.isArray(p)&&p.length===2&&p.every(Number.isFinite)&&p[0]>=0&&p[0]<=W&&p[1]>=0&&p[1]<=H))return '笔画坐标超出画板'
 }
 if(total>1400)return '绘画点数过多，请简化线条'
 return null
}
function validateNew(strokes){
 if(!Array.isArray(strokes)||strokes.length<1||strokes.length>26)throw new Error('AI 返回的笔画数量不符合要求')
 let pointTotal=0
 const sanitized=strokes.map((s)=>{
  if(!s || !Array.isArray(s.points)||s.points.length<2||s.points.length>90)throw new Error('AI 返回的单笔点数无效')
  if(!s.points.every(p=>Array.isArray(p)&&p.length===2&&p.every(Number.isFinite)))throw new Error('AI 返回了无效坐标')
  pointTotal+=s.points.length
  const points=s.points.map(p=>[Math.round(p[0]),Math.round(p[1])])
  if(points.some(p=>p[0]<0||p[0]>W||p[1]<0||p[1]>H))throw new Error('AI 返回了越界坐标')
  return {c:'#423d4b',p:points}
 })
 if(pointTotal>1200)throw new Error('AI 返回的点数过多')
 return sanitized
}

const drawingSchema={
 type:'object',additionalProperties:false,required:['title','reveal','strokes'],
 properties:{
  title:{type:'string',description:'A short playful Chinese title'},
  reveal:{type:'string',description:'One short Chinese sentence explaining the visual twist'},
  strokes:{type:'array',minItems:4,maxItems:22,items:{type:'object',additionalProperties:false,required:['points'],properties:{points:{type:'array',minItems:2,maxItems:65,items:{type:'array',items:{type:'integer'},minItems:2,maxItems:2}}}}}
 }
}
const instructions=`你是《两笔挑战》的黑白简笔画补画搭档，目标类似两笔接力涂鸦游戏。用户已有两笔，绝不可修改、移动、重新描画这两笔。只返回你要【新增】的笔画，不要重新创建整张图。用户原始线条应成为最终形象关键结构（不是背景或装饰）。创作一个清晰、幽默、意料之外但一眼认得出的主体，例如搞怪人物或动物。严禁复杂插画、写实、上色、阴影、填充、背景环境、文字/字母、密集纹理。画面白底，同样粗细的深灰圆头线条；新增 4-16 笔（必要时可到22笔），每笔2-25个关键节点，优先少笔、使用简洁连贯曲线。所有坐标在 800x560 内；坐标系左上角(0,0)，x向右，y向下。保证和用户笔画接触/衔接时坐标精准。切勿复制用户原始笔画做成新增笔画。输出 JSON。`

app.post('/api/complete',async (req,res)=>{
 const access=process.env.GAME_ACCESS_CODE
 if(access && req.get('x-game-access-code')!==access)return res.status(403).json({error:'访问码不正确'})
 const ip=req.ip||'unknown',now=Date.now(),prev=requests.get(ip)||[]
 const recent=prev.filter(t=>now-t<60000)
 if(recent.length>=4)return res.status(429).json({error:'请求太频繁，请一分钟后再试'})
 recent.push(now);requests.set(ip,recent)
 if(requests.size>3000)requests.clear()
 const original=req.body?.strokes
 const invalid=validateOriginal(original)
 if(invalid)return res.status(400).json({error:invalid})
 if(!process.env.OPENAI_API_KEY)return res.status(503).json({error:'尚未配置 OpenAI API Key，请使用演示补画模式'})
 const controller=new AbortController()
 const timeout=setTimeout(()=>controller.abort(),65000)
 try{
  const response=await fetch('https://api.openai.com/v1/responses',{
   method:'POST',signal:controller.signal,
   headers:{'content-type':'application/json',authorization:`Bearer ${process.env.OPENAI_API_KEY}`},
   body:JSON.stringify({
    model:MODEL,store:false,max_output_tokens:4300,
    instructions,
    input:[{role:'user',content:[{type:'input_text',text:`用户两笔的精确点坐标如下。请做有创意的简笔画补全，不要重复原笔画：${JSON.stringify(original)}`}]}],
    text:{format:{type:'json_schema',name:'doodle_completion',strict:true,schema:drawingSchema}}
   })
  })
  const payload=await response.json().catch(()=>({}))
  if(!response.ok){
   console.error('OpenAI request failed',response.status,payload?.error?.code||'unknown')
   return res.status(502).json({error: response.status===401?'API Key 无效或已失效':response.status===429?'OpenAI API 已达到额度或速率限制':'AI 接口暂时不可用，请稍后再试'})
  }
  const output=(payload.output||[]).flatMap(item=>item.content||[]).filter(part=>part.type==='output_text').map(part=>part.text).join('') || payload.output_text || ''
  if(!output)throw new Error('AI 没有返回绘画内容')
  const data=JSON.parse(output)
  const strokes=validateNew(data.strokes)
  res.json({title:String(data.title||'惊喜涂鸦').slice(0,30),reveal:String(data.reveal||'看看这个！').slice(0,150),strokes})
 }catch(e){
  console.error('Completion failed',e?.name||'error',e?.message||'')
  res.status(502).json({error:e?.name==='AbortError'?'AI 响应超时，请再试一次':'AI 笔画生成失败，换一组两笔或重试'})
 }finally{clearTimeout(timeout)}
})
app.use(express.static(path.join(ROOT,'dist')))
app.get('*',(req,res)=>res.sendFile(path.join(ROOT,'dist','index.html'),err=>{if(err&&!res.headersSent)res.status(404).send('请先执行 npm run build')}))
const PORT=Number(process.env.PORT||3000)
app.listen(PORT,'0.0.0.0',()=>console.log(`Two Stroke Studio on port ${PORT}`))
