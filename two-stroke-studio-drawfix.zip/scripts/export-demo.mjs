import {readFile, writeFile, mkdir} from 'node:fs/promises'
import path from 'node:path'
import {fileURLToPath} from 'node:url'
const root=fileURLToPath(new URL('../',import.meta.url))
const dist=path.join(root,'dist')
const built=await readFile(path.join(dist,'index.html'),'utf8')
const jsPath=built.match(/<script[^>]*src="([^"]+\.js)"/)?.[1]
const cssPath=built.match(/<link[^>]*href="([^"]+\.css)"/)?.[1]
if(!jsPath || !cssPath)throw Error('Missing bundled application assets')
const [js,css,example]=await Promise.all([jsPath,cssPath,'/examples/one-edit.json'].map(p=>readFile(path.join(dist,p),'utf8')))
const html='<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>两笔挑战 · 本地试玩</title><style>'+css+'</style></head><body><div id="app"></div><script id="packaged-example" type="application/json">'+example.replaceAll('<','\\u003c')+'</script><script type="module">'+js.replaceAll('</script','<\\/script')+'</script></body></html>'
await mkdir(path.join(root,'demo'),{recursive:true})
await writeFile(path.join(root,'demo','手机试玩版.html'),html)
await writeFile(path.join(dist,'try.html'),html)
