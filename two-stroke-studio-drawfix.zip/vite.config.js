import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import { fileURLToPath } from 'node:url'
export default defineConfig({
  plugins: [vue()],
  root: fileURLToPath(new URL('.', import.meta.url)),
  server: { proxy: { '/api': {target:'http://localhost:3000', changeOrigin:true} } },
  build: { outDir:'dist' }
})
