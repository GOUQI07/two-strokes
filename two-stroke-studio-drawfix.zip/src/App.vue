<script setup>
import {ref, computed, onMounted, onBeforeUnmount, nextTick} from 'vue'
import {loadInk} from './ink.js'
import {guideResult, planDrawing} from '../server/plan.js'
const W=800,H=560
const canvas=ref(null), focusCanvas=ref(null), focusMode=ref(false), gestureReport=ref('等待触摸测试')
const strokes=ref([]), additions=ref([]), temp=ref(null), currentColor=ref('#423d4b')
const phase=ref('draw'), busy=ref(false), message=ref('随意画两笔，AI 会在你的线条上继续补画。')
const artTitle=ref(''), artReveal=ref(''), mode=ref('demo'), accessCode=ref('')
const played=ref(0), playing=ref(false), speed=ref(1), totalLength=ref(0), status=ref(null)
let pid=null, raf=0, previousTime=0, gestureStart=0, gestureLength=0, gestureEvents=0
let inkPlayback = null
let pendingEdit = null
const subjectName=ref(''), subjectVisible=ref(false)
const doneDrawing=computed(()=>strokes.value.length===2)
const pointCount=computed(()=>strokes.value.length)
function pointerPos(e,explicitTarget){const target=explicitTarget||((e.currentTarget instanceof HTMLCanvasElement)?e.currentTarget:(focusMode.value?focusCanvas.value:canvas.value));const r=target.getBoundingClientRect();return [Math.round(Math.max(0,Math.min(W,(e.clientX-r.left)*W/r.width))),Math.round(Math.max(0,Math.min(H,(e.clientY-r.top)*H/r.height)))]}
// 移动端使用原生 Touch Events，并禁用画板上的浏览器手势。
// 鼠标/触控笔仍使用 Pointer Events。不要把 pointercancel 当成完成的一笔。
let touchId=null
function appendPoint(point){
  if(!temp.value)return
  const q=temp.value.p.at(-1)
  if(!q || Math.hypot(point[0]-q[0],point[1]-q[1])>=1.5){if(q)gestureLength+=Math.hypot(point[0]-q[0],point[1]-q[1]);gestureEvents++;temp.value.p.push(point);draw()}
}
function beginStroke(point){
  if(busy.value||phase.value!=='draw'||doneDrawing.value||temp.value)return false
  temp.value={c:currentColor.value,p:[point]};gestureStart=performance.now();gestureLength=0;gestureEvents=0
  draw()
  return true
}
function endStroke(){
  if(!temp.value)return
  const s=temp.value
  temp.value=null
  if(s.p.length){
    strokes.value.push(s)
    message.value=doneDrawing.value?'两笔完成！选择「AI 补画」或「演示补画」。':'很好，再画一笔！'
  }
  gestureReport.value=`本次：${Math.round(performance.now()-gestureStart)}ms · ${gestureEvents}次移动 · ${Math.round(gestureLength)}像素`
  draw()
}
function cancelStroke(){temp.value=null;pid=null;touchId=null;gestureReport.value=`意外中断 · ${gestureEvents}次移动 · ${Math.round(gestureLength)}像素`;message.value='浏览器取消了本次手势，未计数。请试试全屏绘画。';draw()}
function pointerDown(e){
  if(e.pointerType==='touch')return // touch fallback owns touch sequences
  if(pid!==null || !beginStroke(pointerPos(e)))return
  pid=e.pointerId
  try{canvas.value.setPointerCapture(pid)}catch{}
  e.preventDefault()
}
function pointerMove(e){
  if(e.pointerType==='touch'||pid!==e.pointerId||!temp.value)return
  e.preventDefault()
  const samples = e.getCoalescedEvents?.()
  const events = samples?.length ? samples : [e]
  for(const ev of events)appendPoint(pointerPos(ev))
}
function pointerUp(e){
  if(e.pointerType==='touch'||pid!==e.pointerId)return
  appendPoint(pointerPos(e))
  pid=null
  endStroke()
}
function pointerCancel(e){
  if(e.pointerType==='touch'||pid!==e.pointerId)return
  cancelStroke()
}
function touchStart(e){
  // 在画板内，单指绘画优先于页面滚动和缩放。
  if(e.cancelable)e.preventDefault()
  if(touchId!==null||e.touches.length!==1)return
  const t=e.changedTouches[0]
  if(beginStroke(pointerPos(t,e.currentTarget)))touchId=t.identifier
}
function touchMove(e){
  if(e.cancelable)e.preventDefault()
  if(touchId===null || !temp.value)return
  const t=Array.from(e.touches).find(t=>t.identifier===touchId)
  if(t)appendPoint(pointerPos(t,e.currentTarget))
}
function touchEnd(e){
  if(e.cancelable)e.preventDefault()
  if(touchId===null)return
  const t=Array.from(e.changedTouches).find(t=>t.identifier===touchId)
  if(!t)return
  appendPoint(pointerPos(t,e.currentTarget))
  touchId=null
  endStroke()
}
function touchCancel(e){
  if(e.cancelable)e.preventDefault()
  if(touchId!==null && Array.from(e.changedTouches).some(t=>t.identifier===touchId))cancelStroke()
}
function addTouchListeners(target){
  const c=target||canvas.value
  if(!c)return
  c.addEventListener('touchstart',touchStart,{passive:false})
  c.addEventListener('touchmove',touchMove,{passive:false})
  c.addEventListener('touchend',touchEnd,{passive:false})
  c.addEventListener('touchcancel',touchCancel,{passive:false})
}
function removeTouchListeners(target){
  const c=target||canvas.value
  if(!c)return
  c.removeEventListener('touchstart',touchStart)
  c.removeEventListener('touchmove',touchMove)
  c.removeEventListener('touchend',touchEnd)
  c.removeEventListener('touchcancel',touchCancel)
}
function stroke(ctx,s,partial=Infinity){const points=s.p;if(!points?.length)return;ctx.beginPath();ctx.lineWidth=5;ctx.lineJoin='round';ctx.lineCap='round';ctx.strokeStyle=s.c;ctx.fillStyle=s.c;ctx.moveTo(...points[0]);if(points.length===1){ctx.arc(points[0][0],points[0][1],2.5,0,Math.PI*2);ctx.fill();return}const end=Math.min(points.length-1,Math.floor(partial));for(let i=1;i<=end;i++)ctx.lineTo(...points[i]);if(partial<points.length-1){const f=partial-end,a=points[end],b=points[end+1];if(b)ctx.lineTo(a[0]+(b[0]-a[0])*f,a[1]+(b[1]-a[1])*f)}ctx.stroke()}
function drawVectorAdditions(ctx) {
  let remaining = played.value
  for (const line of additions.value) {
    if (remaining <= 0) break
    if (remaining >= line._length) {
      stroke(ctx, line)
      remaining -= line._length
      continue
    }
    for (let i = 1; i < line.p.length; i++) {
      const a = line.p[i - 1], b = line.p[i]
      const length = Math.hypot(b[0] - a[0], b[1] - a[1])
      if (length && remaining <= length) {
        stroke(ctx, line, i - 1 + remaining / length)
        break
      }
      remaining -= length
    }
    break
  }
}
function draw() {
  if (inkPlayback) inkPlayback.seek(totalLength.value ? played.value / totalLength.value : 0)
  for (const surface of [canvas.value, focusCanvas.value]) {
    if (!surface) continue
    const ctx = surface.getContext('2d')
    ctx.fillStyle = '#fffcf7'
    ctx.fillRect(0, 0, W, H)
    if (inkPlayback) ctx.drawImage(inkPlayback.layer, 0, 0)
    else drawVectorAdditions(ctx)
    // User ink is always drawn last, from the exact samples collected on touch.
    for (const line of strokes.value) stroke(ctx, line)
    if (temp.value) stroke(ctx, temp.value)
  }
}
async function toggleFocus(){if(temp.value)cancelStroke();if(focusMode.value){removeTouchListeners(focusCanvas.value);focusMode.value=false;await nextTick();draw()}else{focusMode.value=true;await nextTick();addTouchListeners(focusCanvas.value);draw()}}
function resetPlayback(){cancelAnimationFrame(raf);playing.value=false;played.value=0;previousTime=0;draw()}
function clearAll(){if(busy.value)return;inkPlayback=null;resetPlayback();strokes.value=[];additions.value=[];phase.value='draw';artTitle.value='';artReveal.value='';subjectName.value='';subjectVisible.value=false;message.value='新的画纸！画出两笔，让想象力继续。';draw()}
function undo(){if(busy.value||phase.value!=='draw')return;strokes.value.pop();message.value='已经撤销上一笔。';draw()}
function finishAdditions(data){const arr=data.strokes.map(s=>({c:'#423d4b',p:s.p||s.points}));for(const s of arr){s._length=s.p.slice(1).reduce((n,p,i)=>n+Math.hypot(p[0]-s.p[i][0],p[1]-s.p[i][1]),0)||1}additions.value=arr;totalLength.value=arr.reduce((v,s)=>v+s._length,0);artTitle.value=data.title;artReveal.value=data.reveal;subjectName.value=data.subject || '';subjectVisible.value=false;phase.value='complete';played.value=0;message.value='开始补画啦，请看线条逐笔出现。';startPlayback()}
async function playExample() {
  if (busy.value || strokes.value.length) return
  busy.value = true
  message.value = '正在打开一次生成的样例……'
  try {
    const local = document.getElementById('packaged-example')
    let example
    if (local) example = JSON.parse(local.textContent)
    else {
      const response = await fetch('/examples/one-edit.json')
      if (!response.ok) throw new Error('样例暂时无法打开。')
      example = await response.json()
    }
    inkPlayback = example.ink ? await loadInk(example.ink.map, W, H) : null
    strokes.value = example.original
    finishAdditions(example)
  } catch (error) {
    message.value = error.message
  } finally {
    busy.value = false
  }
}
function demo() {
  if (!strokes.value.length) return playExample()
  if (!doneDrawing.value || busy.value) return
  const plan = planDrawing(strokes.value)
  if (!plan) {message.value='这两笔可用的补画空间太小了。';return}
  inkPlayback = null
  finishAdditions(guideResult(plan))
}
async function aiComplete() {
  if (!doneDrawing.value || busy.value || phase.value !== 'draw') return
  busy.value = true
  message.value = '正在根据两笔的形状画轮廓，请保持画室打开。'
  pendingEdit = new AbortController()
  try {
    const response = await fetch('/api/complete', {
      method:'POST',
      headers:{'content-type':'application/json', 'x-game-access-code':accessCode.value},
      body:JSON.stringify({strokes:strokes.value}),
      signal:pendingEdit.signal
    })
    const data = await response.json().catch(() => ({}))
    if (!response.ok) throw new Error(data.error || '连接中断，原来的两笔已保留。')
    inkPlayback = data.ink ? await loadInk(data.ink.map, W, H) : null
    finishAdditions(data)
  } catch (error) {
    if (error.name !== 'AbortError') message.value = error.message
  } finally {
    busy.value = false
    pendingEdit = null
  }
}
function seekPlayback(e) {
  pausePlayback()
  const rect = e.currentTarget.getBoundingClientRect()
  const fraction = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width))
  played.value = fraction * totalLength.value
  draw()
}
function tick(ts){if(!playing.value)return;const delta=previousTime?Math.min(50,ts-previousTime):0;previousTime=ts;played.value=Math.min(totalLength.value,played.value+delta*0.23*speed.value);draw();if(played.value>=totalLength.value){playing.value=false;message.value='画完啦！你可以回放、保存，或再画一次。';return}raf=requestAnimationFrame(tick)}
function startPlayback(){cancelAnimationFrame(raf);if(!additions.value.length)return;if(played.value>=totalLength.value)played.value=0;playing.value=true;previousTime=0;raf=requestAnimationFrame(tick)}
function pausePlayback(){playing.value=false;cancelAnimationFrame(raf)}
function replay(){played.value=0;startPlayback()}
function exportPng(){if(!canvas.value)return;const old=played.value;played.value=totalLength.value;draw();const url=canvas.value.toDataURL('image/png');played.value=old;draw();const a=document.createElement('a');a.href=url;a.download='两笔挑战-'+Date.now()+'.png';document.body.appendChild(a);a.click();a.remove()}
onMounted(async()=>{await nextTick();addTouchListeners();draw();if(document.getElementById('packaged-example'))return;try{const r=await fetch('/api/health');if(r.ok){status.value=await r.json();if(status.value.aiConfigured)mode.value='ai'}}catch{status.value={aiConfigured:false}}})
onBeforeUnmount(()=>{pendingEdit?.abort();removeTouchListeners();removeTouchListeners(focusCanvas.value);cancelAnimationFrame(raf)})
</script>

<template>
<div class="page">
  <div class="ambient one"></div><div class="ambient two"></div>
  <main class="studio">
    <header><h1>两笔<span>挑战</span><span class="spark">✎</span></h1><p>画两笔，看看它们会变成什么。</p></header>
    <section class="easel">
      <div class="toolbar"><div class="pill"><span class="dot" :class="{pulse:phase==='draw'}"></span>{{busy?'正在补画':phase==='draw'?'轮到你了':playing?'补画进行时':played>=totalLength?'已画完':'已暂停'}}</div><span class="count">{{phase==='draw'?`${pointCount} / 2 笔`:'你的两笔已锁定 ✓'}}</span></div>
      <div class="canvas-frame"><canvas ref="canvas" width="800" height="560" @pointerdown="pointerDown" @pointermove="pointerMove" @pointerup="pointerUp" @pointercancel="pointerCancel" :class="{locked:phase!=='draw'}" aria-label="手指绘画画板"></canvas><span v-if="!pointCount && !temp" class="placeholder">在这里自由画两笔 <span>✳</span></span></div>
      <div class="touch-help"><button type="button" class="focus-btn" @click="toggleFocus">⛶ 全屏绘画（手机推荐）</button><span>{{gestureReport}}</span></div>
      <div class="below"><div class="color-tools"><span class="tool-label">画笔</span><button v-for="c in ['#423d4b','#d97891','#6298be','#8aaf7b']" :key="c" class="color" :class="{selected:currentColor===c}" :style="{'--ink':c}" :disabled="phase!=='draw'" @click="currentColor=c" :aria-label="`选择画笔颜色 ${c}`"></button></div><div class="mini-buttons"><button @click="undo" :disabled="busy||phase!=='draw'||!strokes.length">↶ 撤销</button><button @click="clearAll" :disabled="busy">↻ 新画纸</button></div></div>
    </section>
    <div v-if="focusMode" class="focus-overlay">
      <div class="focus-head"><strong>✏️ 全屏绘画 · {{pointCount}} / 2 笔</strong><button @click="toggleFocus">完成 / 退出全屏</button></div>
      <div class="focus-pad"><canvas ref="focusCanvas" width="800" height="560" @pointerdown="pointerDown" @pointermove="pointerMove" @pointerup="pointerUp" @pointercancel="pointerCancel" aria-label="全屏触屏画板"></canvas></div>
      <div class="focus-foot"><span>{{gestureReport}}</span><button @click="undo" :disabled="busy||!strokes.length">撤销</button><button @click="clearAll" :disabled="busy">清空</button></div>
      <p class="focus-tip">用一根手指画线，抬手完成一笔。</p>
    </div>
    <div class="message" role="status">{{message}}</div>
    <section v-if="phase==='draw'" class="actions"><div class="mode-toggle"><button :disabled="busy" :class="{active:mode==='demo'}" @click="mode='demo'">试玩演示</button><button :disabled="busy" :class="{active:mode==='ai'}" @click="mode='ai'">✦ AI 创意补画</button></div><div v-if="mode==='ai'" class="config"><div class="status" :class="{'ready':status?.aiConfigured}">{{status?.aiConfigured?'● 已配置图像补画':'○ 尚未配置 API Key（可先用演示模式）'}}</div><input v-if="status?.accessCodeRequired" v-model="accessCode" type="password" placeholder="画室访问码" autocomplete="off" /></div><button class="primary" :disabled="busy || (mode==='ai' ? !doneDrawing || !status?.aiConfigured : pointCount === 1)" @click="mode==='demo'?demo():aiComplete()">{{busy?'正在补画……':mode==='ai'?'一笔一笔补完':pointCount===0?'看一轮无标题样例':'按画谱补完'}} <span>→</span></button></section>
    <section v-else class="result"><div class="result-title">{{subjectVisible ? subjectName : artTitle}}</div>
      <button v-if="subjectName && !subjectVisible && played >= totalLength" type="button" class="answer-btn" @click="subjectVisible=true">揭晓画的是什么</button><p v-if="artReveal">{{artReveal}}</p><div class="playback"><button @click="playing?pausePlayback():startPlayback()">{{playing?'Ⅱ 暂停':'▶ 继续'}}</button><button @click="replay">↺ 回放</button><label class="speed">速度<select v-model.number="speed"><option :value="0.5">0.5×</option><option :value="1">1×</option><option :value="2">2×</option><option :value="4">4×</option></select></label></div><div class="progress-track" @click="seekPlayback"><div class="progress-bar" :style="{width:(totalLength?(played/totalLength*100):0)+'%'}"></div></div><div class="result-buttons"><button @click="exportPng">↓ 保存图片</button><button @click="clearAll">✎ 下一轮</button></div></section>
    <footer><small>支持手机触屏 · 800 × 560 画布 · 轮廓版 v6</small></footer>
  </main>
</div>
</template>
