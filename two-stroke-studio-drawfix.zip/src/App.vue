<script setup>
import {ref, computed, onMounted, onBeforeUnmount, nextTick} from 'vue'
const W=800,H=560
const canvas=ref(null), focusCanvas=ref(null), focusMode=ref(false), gestureReport=ref('等待触摸测试')
const strokes=ref([]), additions=ref([]), temp=ref(null), currentColor=ref('#423d4b')
const phase=ref('draw'), busy=ref(false), message=ref('随意画两笔，AI 会在你的线条上继续补画。')
const artTitle=ref(''), artReveal=ref(''), mode=ref('demo'), accessCode=ref('')
const played=ref(0), playing=ref(false), speed=ref(1), totalLength=ref(0), status=ref(null)
let pid=null, raf=0, previousTime=0, gestureStart=0, gestureLength=0, gestureEvents=0, lastTouchAt=0
let strokePaths=[]
const doneDrawing=computed(()=>strokes.value.length===2)
const pointCount=computed(()=>strokes.value.length)
function pointerPos(e,explicitTarget){const target=explicitTarget||((e.currentTarget instanceof HTMLCanvasElement)?e.currentTarget:(focusMode.value?focusCanvas.value:canvas.value));const r=target.getBoundingClientRect();return [Math.round(Math.max(0,Math.min(W,(e.clientX-r.left)*W/r.width))),Math.round(Math.max(0,Math.min(H,(e.clientY-r.top)*H/r.height)))]}
// 移动端使用原生 Touch Events，并禁用画板上的浏览器手势。
// 鼠标/触控笔仍使用 Pointer Events。不要把 pointercancel 当成完成的一笔。
let touchId=null
function appendPoint(point){
  if(!temp.value)return
  const q=temp.value.p.at(-1)
  if(!q || Math.hypot(point[0]-q[0],point[1]-q[1])>=1.5){if(q)gestureLength+=Math.hypot(point[0]-q[0],point[1]-q[1]);gestureEvents++;temp.value.p.push(point);draw()}
}
function beginStroke(point){
  if(phase.value!=='draw'||doneDrawing.value||temp.value)return false
  temp.value={c:currentColor.value,p:[point]};gestureStart=performance.now();gestureLength=0;gestureEvents=0
  draw()
  return true
}
function endStroke(){
  if(!temp.value)return
  const s=temp.value
  temp.value=null
  if(s.p.length>1 && gestureLength>=35 && gestureEvents>=2){
    strokes.value.push(s)
    message.value=doneDrawing.value?'两笔完成！选择「AI 补画」或「演示补画」。':'很好，再画一笔！'
  }else message.value='没有收到足够的连续移动，已忽略短线，不占用两笔。请试试全屏绘画。'
  gestureReport.value=`本次：${Math.round(performance.now()-gestureStart)}ms · ${gestureEvents}次移动 · ${Math.round(gestureLength)}像素`
  draw()
}
function cancelStroke(){temp.value=null;pid=null;touchId=null;gestureReport.value=`意外中断 · ${gestureEvents}次移动 · ${Math.round(gestureLength)}像素`;message.value='浏览器取消了本次手势，未计数。请试试全屏绘画。';draw()}
function pointerDown(e){
  if(e.pointerType==='touch')return // touch fallback owns touch sequences
  if(pid!==null || !beginStroke(pointerPos(e)))return
  pid=e.pointerId
  try{canvas.value.setPointerCapture(pid)}catch{}
  e.preventDefault()
}
function pointerMove(e){
  if(e.pointerType==='touch'||pid!==e.pointerId||!temp.value)return
  e.preventDefault()
  const events=typeof e.getCoalescedEvents==='function'?e.getCoalescedEvents():[e]
  for(const ev of events)appendPoint(pointerPos(ev))
}
function pointerUp(e){
  if(e.pointerType==='touch'||pid!==e.pointerId)return
  appendPoint(pointerPos(e))
  pid=null
  endStroke()
}
function pointerCancel(e){
  if(e.pointerType==='touch'||pid!==e.pointerId)return
  cancelStroke()
}
function touchStart(e){
  // 在画板内，单指绘画优先于页面滚动和缩放。
  if(e.cancelable)e.preventDefault()
  if(touchId!==null||e.touches.length!==1)return
  const t=e.changedTouches[0]
  if(beginStroke(pointerPos(t,e.currentTarget)))touchId=t.identifier
}
function touchMove(e){
  if(e.cancelable)e.preventDefault()
  if(touchId===null || !temp.value)return
  const t=Array.from(e.touches).find(t=>t.identifier===touchId)
  if(t)appendPoint(pointerPos(t,e.currentTarget))
}
function touchEnd(e){
  if(e.cancelable)e.preventDefault()
  if(touchId===null)return
  const t=Array.from(e.changedTouches).find(t=>t.identifier===touchId)
  if(!t)return
  appendPoint(pointerPos(t,e.currentTarget))
  touchId=null
  endStroke()
}
function touchCancel(e){
  if(e.cancelable)e.preventDefault()
  if(touchId!==null && Array.from(e.changedTouches).some(t=>t.identifier===touchId))cancelStroke()
}
function addTouchListeners(target){
  const c=target||canvas.value
  if(!c)return
  c.addEventListener('touchstart',touchStart,{passive:false})
  c.addEventListener('touchmove',touchMove,{passive:false})
  c.addEventListener('touchend',touchEnd,{passive:false})
  c.addEventListener('touchcancel',touchCancel,{passive:false})
}
function removeTouchListeners(target){
  const c=target||canvas.value
  if(!c)return
  c.removeEventListener('touchstart',touchStart)
  c.removeEventListener('touchmove',touchMove)
  c.removeEventListener('touchend',touchEnd)
  c.removeEventListener('touchcancel',touchCancel)
}
function stroke(ctx,s,partial=Infinity){const points=s.p;if(!points?.length)return;ctx.beginPath();ctx.lineWidth=5;ctx.lineJoin='round';ctx.lineCap='round';ctx.strokeStyle=s.c;ctx.fillStyle=s.c;ctx.moveTo(...points[0]);if(points.length===1){ctx.arc(points[0][0],points[0][1],2.5,0,Math.PI*2);ctx.fill();return}const end=Math.min(points.length-1,Math.floor(partial));for(let i=1;i<=end;i++)ctx.lineTo(...points[i]);if(partial<points.length-1){const f=partial-end,a=points[end],b=points[end+1];if(b)ctx.lineTo(a[0]+(b[0]-a[0])*f,a[1]+(b[1]-a[1])*f)}ctx.stroke()}
function draw(){for(const c of [canvas.value,focusCanvas.value]){if(!c)continue;const ctx=c.getContext('2d');ctx.fillStyle='#fffcf7';ctx.fillRect(0,0,W,H);for(const s of strokes.value)stroke(ctx,s);if(temp.value)stroke(ctx,temp.value);let remain=played.value;for(const s of additions.value){let len=s._length||1;if(remain<=0)break;if(remain>=len)stroke(ctx,s);else{let dist=remain;let idx=0;while(idx<s.p.length-1){let a=s.p[idx],b=s.p[idx+1],l=Math.hypot(b[0]-a[0],b[1]-a[1]);if(dist<=l){stroke(ctx,s,idx+(l?dist/l:0));break}dist-=l;idx++}}remain-=len}}}
async function toggleFocus(){if(temp.value)cancelStroke();if(focusMode.value){removeTouchListeners(focusCanvas.value);focusMode.value=false;await nextTick();draw()}else{focusMode.value=true;await nextTick();addTouchListeners(focusCanvas.value);draw()}}
function resetPlayback(){cancelAnimationFrame(raf);playing.value=false;played.value=0;previousTime=0;draw()}
function clearAll(){resetPlayback();strokes.value=[];additions.value=[];phase.value='draw';artTitle.value='';artReveal.value='';message.value='新的画纸！画出两笔，让想象力继续。';draw()}
function undo(){if(phase.value!=='draw')return;strokes.value.pop();message.value='已经撤销上一笔。';draw()}
function finishAdditions(data){const arr=data.strokes.map(s=>({c:'#423d4b',p:s.p||s.points}));for(const s of arr){s._length=s.p.slice(1).reduce((n,p,i)=>n+Math.hypot(p[0]-s.p[i][0],p[1]-s.p[i][1]),0)||1}additions.value=arr;totalLength.value=arr.reduce((v,s)=>v+s._length,0);artTitle.value=data.title;artReveal.value=data.reveal;phase.value='complete';played.value=0;message.value='开始补画啦，原始两笔不会被修改！';startPlayback()}
function shape(points){return {p:points.map(p=>p.map(Math.round))}}
function demo(){if(!doneDrawing.value)return;const all=strokes.value.flatMap(s=>s.p);let minX=Math.min(...all.map(p=>p[0])),maxX=Math.max(...all.map(p=>p[0])),minY=Math.min(...all.map(p=>p[1])),maxY=Math.max(...all.map(p=>p[1]));const cx=Math.min(650,Math.max(150,(minX+maxX)/2));const cy=Math.min(395,Math.max(135,(minY+maxY)/2));const clamp=(x,y)=>[Math.min(796,Math.max(4,Math.round(x))),Math.min(556,Math.max(4,Math.round(y)))];const line=(coords)=>shape(coords.map(p=>clamp(...p)));const r=[line([[cx-68,cy-65],[cx-56,cy-89],[cx-42,cy-68]]),line([[cx+40,cy-67],[cx+55,cy-88],[cx+68,cy-62]]),line([[cx-35,cy-22],[cx-31,cy-29],[cx-26,cy-21]]),line([[cx+22,cy-22],[cx+28,cy-29],[cx+33,cy-19]]),line([[cx-21,cy+10],[cx-10,cy+20],[cx+4,cy+22],[cx+18,cy+9]]),line([[cx-66,cy+10],[cx-105,cy+1]]),line([[cx-67,cy+21],[cx-111,cy+28]]),line([[cx+68,cy+11],[cx+107,cy-1]]),line([[cx+69,cy+24],[cx+114,cy+30]])];finishAdditions({title:'一只迷糊的小怪兽',reveal:'这是无 API Key 的示意演示：新增线条是预设的，不代表 AI 实际理解了你的笔画。',strokes:r})}
async function aiComplete(){if(!doneDrawing.value||busy.value)return;busy.value=true;message.value='AI 正在琢磨你的两笔会变成什么……';try{const r=await fetch('/api/complete',{method:'POST',headers:{'content-type':'application/json',...(accessCode.value?{'x-game-access-code':accessCode.value}:{})},body:JSON.stringify({strokes:strokes.value})});const data=await r.json();if(!r.ok)throw Error(data.error||'请求失败');finishAdditions(data)}catch(e){message.value='⚠️ '+e.message}finally{busy.value=false}}
function tick(ts){if(!playing.value)return;const delta=previousTime?Math.min(50,ts-previousTime):0;previousTime=ts;played.value=Math.min(totalLength.value,played.value+delta*0.23*speed.value);draw();if(played.value>=totalLength.value){playing.value=false;message.value='画完啦！你可以回放、保存，或再画一次。';return}raf=requestAnimationFrame(tick)}
function startPlayback(){cancelAnimationFrame(raf);if(!additions.value.length)return;if(played.value>=totalLength.value)played.value=0;playing.value=true;previousTime=0;raf=requestAnimationFrame(tick)}
function pausePlayback(){playing.value=false;cancelAnimationFrame(raf)}
function replay(){played.value=0;startPlayback()}
function exportPng(){if(!canvas.value)return;const old=played.value;played.value=totalLength.value;draw();const url=canvas.value.toDataURL('image/png');played.value=old;draw();const a=document.createElement('a');a.href=url;a.download='两笔挑战-'+Date.now()+'.png';document.body.appendChild(a);a.click();a.remove()}
onMounted(async()=>{await nextTick();addTouchListeners();draw();try{const r=await fetch('/api/health');if(r.ok){status.value=await r.json();if(status.value.aiConfigured)mode.value='ai'}}catch{status.value={aiConfigured:false}}})
onBeforeUnmount(()=>{removeTouchListeners();removeTouchListeners(focusCanvas.value);cancelAnimationFrame(raf)})
</script>

<template>
<div class="page">
  <div class="ambient one"></div><div class="ambient two"></div>
  <main class="studio">
    <header><div class="eyebrow">✦ DRAW • IMAGINE • REVEAL ✦</div><h1>两笔<span>挑战</span><span class="spark">✎</span></h1><p>你画两笔，我把故事画完。</p></header>
    <section class="easel">
      <div class="toolbar"><div class="pill"><span class="dot" :class="{pulse:phase==='draw'}"></span>{{phase==='draw'?'轮到你了':'补画进行时'}}</div><span class="count">{{phase==='draw'?`${pointCount} / 2 笔`:'你的两笔已锁定 ✓'}}</span></div>
      <div class="canvas-frame"><canvas ref="canvas" width="800" height="560" @pointerdown="pointerDown" @pointermove="pointerMove" @pointerup="pointerUp" @pointercancel="pointerCancel" :class="{locked:phase!=='draw'}" aria-label="手指绘画画板"></canvas><span v-if="!pointCount" class="placeholder">在这里自由画两笔 <span>✳</span></span></div>
      <div class="touch-help"><button type="button" class="focus-btn" @click="toggleFocus">⛶ 全屏绘画（手机推荐）</button><span>{{gestureReport}}</span></div>
      <div class="below"><div class="color-tools"><span class="tool-label">画笔</span><button v-for="c in ['#423d4b','#d97891','#6298be','#8aaf7b']" :key="c" class="color" :class="{selected:currentColor===c}" :style="{'--ink':c}" :disabled="phase!=='draw'" @click="currentColor=c" :aria-label="`选择画笔颜色 ${c}`"></button></div><div class="mini-buttons"><button @click="undo" :disabled="phase!=='draw'||!strokes.length">↶ 撤销</button><button @click="clearAll">↻ 新画纸</button></div></div>
    </section>
    <div v-if="focusMode" class="focus-overlay">
      <div class="focus-head"><strong>✏️ 全屏绘画 · {{pointCount}} / 2 笔</strong><button @click="toggleFocus">完成 / 退出全屏</button></div>
      <div class="focus-pad"><canvas ref="focusCanvas" width="800" height="560" @pointerdown="pointerDown" @pointermove="pointerMove" @pointerup="pointerUp" @pointercancel="pointerCancel" aria-label="全屏触屏画板"></canvas></div>
      <div class="focus-foot"><span>{{gestureReport}}</span><button @click="undo" :disabled="!strokes.length">撤销</button><button @click="clearAll">清空</button></div>
      <p class="focus-tip">手指按住画板连续滑动。少于 35 像素的异常短线不会计数。</p>
    </div>
    <div class="message" role="status">{{message}}</div>
    <section v-if="phase==='draw'" class="actions"><div class="mode-toggle"><button :class="{active:mode==='demo'}" @click="mode='demo'">试玩演示</button><button :class="{active:mode==='ai'}" @click="mode='ai'">✦ AI 创意补画</button></div><div v-if="mode==='ai'" class="config"><div class="status" :class="{'ready':status?.aiConfigured}">{{status?.aiConfigured?'● OpenAI API 已就绪':'○ 尚未配置 API Key（可先用演示模式）'}}</div><input v-model="accessCode" type="password" placeholder="访问码（仅当站长设置时填写）" autocomplete="off" /></div><button class="primary" :disabled="!doneDrawing||busy" @click="mode==='demo'?demo():aiComplete()">{{busy?'正在构思……':mode==='ai'?'✨ 让 AI 接着画':'▶ 播放示范补画'}} <span>→</span></button></section>
    <section v-else class="result"><div class="result-title">{{artTitle}}</div><p>{{artReveal}}</p><div class="playback"><button @click="playing?pausePlayback():startPlayback()">{{playing?'Ⅱ 暂停':'▶ 继续'}}</button><button @click="replay">↺ 回放</button><label class="speed">速度<select v-model.number="speed"><option :value="0.5">0.5×</option><option :value="1">1×</option><option :value="2">2×</option><option :value="4">4×</option></select></label></div><div class="progress-track" @click="e=>{pausePlayback();played=(e.offsetX/e.currentTarget.clientWidth)*totalLength;draw()}"><div class="progress-bar" :style="{width:(totalLength?(played/totalLength*100):0)+'%'}"></div></div><div class="result-buttons"><button @click="exportPng">↓ 保存图片</button><button @click="clearAll">✎ 下一轮</button></div></section>
    <footer><span>✿ 两笔永远是你的，AI 只负责添加新的故事。</span><small>支持手机触屏 · 800 × 560 画布 · 绘制修复 v4</small></footer>
  </main>
</div>
</template>
