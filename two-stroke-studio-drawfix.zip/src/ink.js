// Decode once. During playback only pixels whose time has changed are updated.
export async function loadInk(map, width, height) {
  if (typeof map !== 'string' || !map.startsWith('data:image/png;base64,')) {
    throw new Error('补画图层格式异常')
  }
  const img = new Image()
  img.src = map
  await img.decode()
  if (img.naturalWidth !== width || img.naturalHeight !== height) {
    throw new Error('补画图层与画板尺寸不符')
  }
  const layer = document.createElement('canvas')
  layer.width = width
  layer.height = height
  const ctx = layer.getContext('2d', {willReadFrequently:true})
  ctx.drawImage(img, 0, 0)
  const encoded = ctx.getImageData(0, 0, width, height).data
  const frame = ctx.createImageData(width, height)
  const byTime = []
  for (let offset = 0; offset < encoded.length; offset += 4) {
    if (encoded[offset + 2] === 0) continue
    byTime.push(offset)
    frame.data[offset] = 0x42
    frame.data[offset + 1] = 0x3d
    frame.data[offset + 2] = 0x4b
  }
  const rank = offset => encoded[offset] * 256 + encoded[offset + 1]
  byTime.sort((a, b) => rank(a) - rank(b))
  let visible = 0
  ctx.clearRect(0, 0, width, height)
  return {
    layer,
    seek(fraction) {
      const time = Math.round(Math.min(1, Math.max(0, fraction)) * 65535)
      const previous = visible
      while (visible > 0 && rank(byTime[visible - 1]) > time) {
        frame.data[byTime[--visible] + 3] = 0
      }
      while (visible < byTime.length && rank(byTime[visible]) <= time) {
        const offset = byTime[visible++]
        frame.data[offset + 3] = encoded[offset + 2]
      }
      if (previous !== visible) ctx.putImageData(frame, 0, 0)
    },
  }
}
