# 两笔挑战 · 自由补画版 v7

在 800 × 560 画板上画两笔，点击「AI 自由补画」。Node 服务向 OpenAI 图像编辑接口发送一次请求，输入是你的两条原线和保护遮罩。模型根据原线选择题材并补画。服务将回图对齐，提取新增墨迹，Vue 画板按程序重建的笔序播放。原来的两笔始终按输入坐标和颜色绘制在最上层。

AI 回图无法对齐或提取时，页面保留画纸并显示原因。再点 AI 补画会发起新请求。「参考画法（免费）」使用本地画谱，适合离线试玩。没有适合的参考图案时，保留两笔并提示。空画板可播放预录的一轮样例。普通画板和全屏触控画板均支持回放、变速、保存 PNG。

## 手机部署

将完整项目压缩包以 `two-stroke-studio-drawfix.zip` 的文件名放在 GitHub 仓库根目录。原 Render 服务使用构建命令 `unzip -o two-stroke-studio-drawfix.zip && npm install && npm run build`，启动命令 `npm start`。等待部署变为 Live，页脚应显示「自由补画版 v7」，健康检查 `/api/health` 返回 `free-draw-v7`。

## 本地运行

使用 Node.js 22.16 或更高版本。执行以下命令后打开 http://localhost:3000 。

```sh
npm install
cp .env.example .env
npm test
npm run build
npm start
```

在服务器设置 `OPENAI_API_KEY`，可选设置 `OPENAI_IMAGE_MODEL`、`PORT`、`GAME_ACCESS_CODE`。关闭页面不会自动重试付费请求。离线试玩文件为 `demo/手机试玩版.html`，部署后的试玩路径为 `/try.html`。
