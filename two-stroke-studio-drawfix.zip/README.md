# 两笔挑战 · 单次补画 v5

玩家在 800 × 560 画板上画两笔，按下「一笔一笔补完」，网站向 OpenAI 发出一次图像编辑请求。创作目标是手机上不用读标题也能认出的简笔画。普通画板和全屏画板均支持逐笔回放、暂停、变速和导出 PNG。

## 用手机更新已有的 Render 网站

本版沿用 v4 部署包的文件名，以便原服务直接读取。

1. 将新版 `two-stroke-studio-drawfix.zip` 上传至 GitHub 仓库根目录，替换旧的同名文件。在 `main` 上提交修改。如果手机下载时自动加了 `(1)`，先改回原名。
2. 在 Render 的服务页查看最新提交的部署记录。开启自动部署时，等状态变为 **Live**。手动部署时选择 **Manual Deploy → Deploy latest commit**。
3. 打开网站并刷新。页脚显示 **单次补画 v5**。服务的 `/api/health` 会返回 `"version":"single-edit-v5"`。
4. 配置过的 `OPENAI_API_KEY` 和 `GAME_ACCESS_CODE` 仍由 Render 注入。该 Key 所属的 OpenAI 项目需要有图像模型权限和可用余额。

旧服务的 Build Command 应为 `unzip -o two-stroke-studio-drawfix.zip && npm install && npm run build`，Start Command 为 `npm start`。选择 Node.js 22.16 或更新版本。Render 安装 sharp 时使用 npm 的默认可选依赖设置。

在空画板选择「试玩演示 → 回放上次两笔的样例」，可以直接回放已打包的小狗，无需 API Key。该样例来自聊天中的一次图像编辑，沿用本项目的线条提取和回放程序。

## 创作和播放

- 后端依照原始坐标制作图像参考，给原线临时着蓝色以便提取新增墨迹。同时提供保护原线的遮罩。玩家在屏幕上始终看到自己选的笔色。
- `POST /v1/images/edits` 一轮请求一幅图，默认模型为 `gpt-image-2.6-sunburst`，质量为 `high`。模型直接看形状，自行选择一个形象，利用两笔的弯折和端点画出轮廓与识别特征。
- 本地程序检查位置、分离新增墨迹，根据轮廓中心线安排显现顺序。动画使用新增墨迹本身，所以眼睛、线宽和转角都保留。播放顺序由程序重建。
- 前端在新增墨迹上方重绘原始笔画。拖动进度、回放和保存图片都只在设备上进行。
- 图像编辑由 OpenAI 按实际用量计费。单次创作仍可能有等待时间或得到难以辨认的结果。无法提取或对齐线条时，页面会保留原画并显示错误。服务不会为失败的回图自动发起第二次生成。再次按补画按钮会启动新的一次请求。

## 本地启动

需要 Node.js 22.16+ 和 npm。

```sh
npm install
cp .env.example .env
npm test
npm run build
npm start
```

浏览器打开 `http://localhost:3000`。前端开发时可同时运行 `npm run dev:server` 与 `npm run dev`。测试采用模拟的 OpenAI 回图，不使用密钥或额度。

| 环境变量 | 用途 |
| --- | --- |
| `OPENAI_API_KEY` | OpenAI 服务端密钥 |
| `OPENAI_IMAGE_MODEL` | 可选。默认 `gpt-image-2.6-sunburst`，也可指定当前项目有权限且支持遮罩、PNG、指定图幅和 high 质量的图像编辑模型 |
| `GAME_ACCESS_CODE` | 可选。设置后，访问者输入画室口令才能使用付费接口 |
| `PORT` | 默认 3000 |

服务只用图像编辑接口。旧的文本模型环境变量 `OPENAI_MODEL` 在本版不参与调用。不要将密钥写入仓库或前端。

[OpenAI 图像编辑接口](https://developers.openai.com/api/reference/resources/images/methods/edit)
