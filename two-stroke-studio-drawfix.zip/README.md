# 两笔挑战 · 轮廓版 v6

在手机上画两笔，画室从原线的弯折、间距和走向选题，用少量线条组成可以辨认的简笔画。先猜画的是谁，播放完再点「揭晓画的是什么」。普通及全屏画板均可暂停、变速、回放和保存 PNG。

## 手机更新

1. 将新版 ZIP 以 `two-stroke-studio-drawfix.zip` 这个文件名传到 GitHub 仓库根目录并提交，覆盖同名旧文件。手机下载时如果加了数字后缀，上传前改回原名。
2. 原 Render 服务继续使用构建命令 `unzip -o two-stroke-studio-drawfix.zip && npm install && npm run build`，启动命令 `npm start`。开启自动部署时等最新提交变为 Live；手动部署时选择 Manual Deploy → Deploy latest commit。
3. 刷新网站，页脚应显示「轮廓版 v6」。`/api/health` 对应的 version 是 `silhouette-v6`。沿用已设置的 `OPENAI_API_KEY` 与可选的 `GAME_ACCESS_CODE`。

## 试玩与 AI 创作

- 空画板选「试玩演示 → 看一轮无标题样例」，会回放一组测试线条的一次图像编辑样例。
- 也可以画自己的两笔，选「试玩演示 → 按画谱补完」。这个模式在手机上计算构图并生成新线。压缩包内的 `demo/手机试玩版.html` 是内含脚本、样例的离线试玩版，部署后的路径为 `/try.html`。
- 「AI 创意补画」每轮只调用一次官方图像编辑接口。模型在蓝色原线及粉色参考轮廓的基础上补齐特征，网站从实际回图取出新增墨迹，按轮廓顺序播放。原线按原坐标、原颜色叠在画面最上层。播放顺序是程序重建的。
- 本地检查将成图和该构图的标志性部位进行位置、方向、覆盖度和留白比较。例如小象的卷鼻和扇耳都要匹配。它衡量轮廓相似度；玩家的辨认仍是最终标准。
- 如果回图不能对齐或关键部位不够接近，游戏改用已经与原线对齐的参考画法，结果会标明来源。这种情况已经产生一次图像请求的费用。服务不自动重画。账户权限、额度、网络等错误会单独提示，原画会保留。
- v6 采用有限题材以减少模糊的动物形象。基础画谱包括小象、兔子、鲸鱼、蜗牛、茶壶、帆船、鸭子和雨伞。两笔还可组成茶壶与热气、船与水面等场景。难以匹配主体时会尝试水母的触手、风筝的线等更自由的布局。题材可能重复。

## 运行与配置

要求 Node.js 22.16+。使用 npm 默认的可选依赖以安装 sharp。

```sh
npm install
cp .env.example .env
npm test
npm run build
npm start
```

浏览器打开 `http://localhost:3000`。开发前端和后端可在两个终端分别执行 `npm run dev` 与 `npm run dev:server`。

| 变量 | 用途 |
| --- | --- |
| OPENAI_API_KEY | 服务器端 OpenAI Key |
| OPENAI_IMAGE_MODEL | 图像编辑模型，默认 gpt-image-2.6-sunburst。需要项目拥有相应模型权限 |
| GAME_ACCESS_CODE | 选填；设置后，访客要输入画室访问码才能使用付费接口 |
| PORT | 默认 3000 |

测试使用本地构造的回图，不产生 API 费用。内置的小象样例由图像生成工具在两条测试曲线上一次补画，再通过项目的提取、轮廓检查和播放流程制作。

[OpenAI 图像编辑接口](https://developers.openai.com/api/reference/resources/images/methods/edit)
