import {createDoodleEdit} from './image-edit.js'
import {traceEdit} from './trace.js'
import {makeRevealMap} from './reveal.js'

export async function completeDrawing(original, {edit = createDoodleEdit, ...options} = {}) {
  const raster = await edit(original, options)
  let addition
  try {
    addition = traceEdit({...raster, original})
  } catch (error) {
    if (error.code === 'UNUSABLE_EDIT') {
      error.status = 422
      error.publicMessage = '本轮 AI 回图未能提取到与原线对齐的清晰笔画。你的两笔已保留。'
    }
    throw error
  }
  const {strokes, inkAlpha} = addition
  const map = await makeRevealMap(strokes, inkAlpha, raster.width, raster.height)
  return {title:'两笔成画', subject:'', source:'ai-edit', reveal:'AI 自由补画', strokes, ink:{map}}
}
