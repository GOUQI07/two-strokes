import {createDoodleEdit} from './image-edit.js'
import {traceEdit} from './trace.js'
import {makeRevealMap} from './reveal.js'
import {guideResult, planDrawing} from './plan.js'
import {evaluateFeatures} from './recognition.js'

export async function completeDrawing(original, {edit=createDoodleEdit, ...options}={}) {
  const plan=planDrawing(original)
  if(!plan) throw Object.assign(new Error('无法布局'),{status:422,publicMessage:'这两笔贴近画板边缘，缺少补画空间。可以撤销重画。'})
  const raster=await edit(original, {...options,plan})
  let addition
  try {
    addition=traceEdit({...raster,original})
  } catch(error) {
    if(error.code==='UNUSABLE_EDIT')return guideResult(plan,true)
    throw error
  }
  const verdict=evaluateFeatures(original,addition.inkAlpha,raster.width,raster.height,plan.features,plan.strokes)
  if(!verdict.passed)return guideResult(plan,true)
  const map=await makeRevealMap(addition.strokes,addition.inkAlpha,raster.width,raster.height)
  return {title:'两笔成画',subject:plan.subject.name,source:'ai-edit',reveal:'',strokes:addition.strokes,ink:{map}}
}
