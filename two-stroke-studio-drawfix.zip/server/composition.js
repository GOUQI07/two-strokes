import {subjects} from './subjects.js'

const WIDTH = 800, HEIGHT = 560
const SAMPLE_COUNT = 13
const RANGES = [[0, 1], [0, .65], [.35, 1], [.2, .8]]
const cache = new WeakMap()

function pathInfo(points) {
  const cumulative = [0]
  for (let i = 1; i < points.length; i++) {
    const prev = points[i - 1], next = points[i]
    cumulative.push(cumulative[i - 1] + Math.hypot(next[0] - prev[0], next[1] - prev[1]))
  }
  return {points, cumulative, length:cumulative.at(-1)}
}

function pointAt(curve, fraction) {
  if (fraction <= 0 || !curve.length) return curve.points[0]
  if (fraction >= 1) return curve.points.at(-1)
  const target = curve.length * fraction
  let lo = 0, hi = curve.cumulative.length - 1
  while (lo + 1 < hi) {
    const mid = (lo + hi) >> 1
    if (curve.cumulative[mid] < target) lo = mid
    else hi = mid
  }
  const t = (target - curve.cumulative[lo]) / (curve.cumulative[hi] - curve.cumulative[lo] || 1)
  const a = curve.points[lo], b = curve.points[hi]
  return [a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1])]
}

function sample(curve, from = 0, to = 1) {
  return Array.from({length:SAMPLE_COUNT}, (_, i) => pointAt(curve, from + (to - from) * i / (SAMPLE_COUNT - 1)))
}

function moments(points) {
  let x = 0, y = 0
  for (const p of points) { x += p[0]; y += p[1] }
  x /= points.length
  y /= points.length
  const centered = points.map(p => [p[0] - x, p[1] - y])
  const energy = centered.reduce((sum, [a,b]) => sum + a*a + b*b, 0)
  return {x,y,centered,energy}
}

function catalogEntry(subject) {
  if (cache.has(subject)) return cache.get(subject)
  const choices = []
  const curves = subject.strokes.map(s => pathInfo(s.p))
  const all = subject.strokes.flatMap(s => s.p)
  const xs = all.map(p => p[0]), ys = all.map(p => p[1])
  const bounds = [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)]
  for (const [index, stroke] of subject.strokes.entries()) {
    if (!stroke.anchor || curves[index].length < 14) continue
    for (const [from, to] of RANGES) {
      const length = (to - from) * curves[index].length
      if (length < 14) continue
      for (const reversed of [false, true]) {
        const points = sample(curves[index], reversed ? to : from, reversed ? from : to)
        choices.push({index, from, to, reversed, points, length, ...moments(points)})
      }
    }
  }
  const result = {subject, curves, bounds, choices}
  cache.set(subject, result)
  return result
}

function transform(p, m) {
  return [m.a*p[0] + m.c*p[1] + m.x, m.b*p[0] + m.d*p[1] + m.y]
}

// Evaluate path correspondences by arc length. The second stroke contributes
// the same weight as the first, including when the first is very long.
function matchPair(entry, first, second, targets, mirror) {
  if (first.index === second.index) return null
  const [t1,t2] = targets
  const ratio = (t1.length / first.length) / (t2.length / second.length)
  if (ratio < .69 || ratio > 1.45) return null
  const dx = (first.x - second.x)*mirror, dy = first.y - second.y
  const du = t1.x - t2.x, dv = t1.y - t2.y
  const count = SAMPLE_COUNT / 2
  const energy = first.energy + second.energy + count*(dx*dx + dy*dy)
  if (energy < 1) return null
  let dot = count*(dx*du + dy*dv), cross = count*(dx*dv - dy*du)
  const pair = [first,second]
  for (let j = 0; j < 2; j++) {
    for (let i = 0; i < SAMPLE_COUNT; i++) {
      const [px,py] = pair[j].centered[i], [u,v] = targets[j].centered[i]
      dot += mirror*px*u + py*v
      cross += mirror*px*v - py*u
    }
  }
  const cos = dot/energy, sin = cross/energy
  const angle = Math.abs(Math.atan2(sin,cos))
  if (angle > .61) return null
  const scale = Math.hypot(cos,sin)
  const [left,top,right,bottom] = entry.bounds
  const size = scale*Math.max(right-left,bottom-top)
  if (size < 105 || size > 796) return null
  const mx=(first.x+second.x)*mirror/2, my=(first.y+second.y)/2
  const m = {a:cos*mirror,b:sin*mirror,c:-sin,d:cos,
    x:(t1.x+t2.x)/2 - cos*mx + sin*my,
    y:(t1.y+t2.y)/2 - sin*mx - cos*my}
  // If even the center is off the page, don't warp or partially crop a subject.
  const center=transform([(left+right)/2,(top+bottom)/2],m)
  if (center[0] < 0 || center[0] > WIDTH || center[1] < 0 || center[1] > HEIGHT) return null
  let worst = 0, total = 0
  const mapped = []
  for (let j = 0; j < 2; j++) {
    const src=pair[j], dst=targets[j]
    const lenRatio = dst.length/(scale*src.length)
    if (lenRatio < .75 || lenRatio > 1.34) return null
    const tolerance=3 + Math.min(size*.065, dst.length*.13)
    const aligned = src.points.map(p => transform(p,m))
    mapped.push(aligned)
    let sum2=0, peak=0
    for (let i=0; i<SAMPLE_COUNT; i++) {
      const [x,y]=aligned[i], [u,v]=dst.points[i]
      const distance=Math.hypot(u-x,v-y)
      sum2 += distance*distance
      peak = Math.max(peak,distance)
    }
    const rms = Math.sqrt(sum2/SAMPLE_COUNT)
    if (rms > tolerance || peak > tolerance*1.85) return null
    const error = rms/tolerance + .23*peak/tolerance + .45*Math.abs(Math.log(lenRatio))
    worst = Math.max(worst,error)
    total += error*.5
  }
  // Prefer full semantic parts and a stable upright pose among equivalent fits.
  const cost=.56*worst+.44*total + .06*angle + .18*(2-first.to+first.from-second.to+second.from)
  if (cost > 1.08) return null
  return {entry,m,size,pair,mapped,cost}
}

function sliceCurve(curve, lo, hi) {
  if (hi <= lo) return []
  const middle = curve.points.filter((_,i) => curve.cumulative[i] > lo*curve.length && curve.cumulative[i] < hi*curve.length)
  return [pointAt(curve,lo), ...middle, pointAt(curve,hi)]
}

function projection(x,y, a,b) {
  const dx=b[0]-a[0], dy=b[1]-a[1], length2=dx*dx+dy*dy
  const t=length2?Math.min(1,Math.max(0,((x-a[0])*dx+(y-a[1])*dy)/length2)):0
  const xx=a[0]+t*dx, yy=a[1]+t*dy
  return {t,x:xx,y:yy,d:Math.hypot(x-xx,y-yy)}
}

function realize(fit, targets, original) {
  const {entry,m,pair,size,mapped}=fit
  // Check source junctions across both anchors before stretching any joining
  // lines. A shared endpoint cannot legitimately snap to two distant places.
  for (const i of pair.length === 2 ? [0,SAMPLE_COUNT-1] : []) {
    for (const j of [0,SAMPLE_COUNT-1]) {
      const a=mapped[0][i], b=mapped[1][j], p=targets[0].points[i], q=targets[1].points[j]
      if (Math.hypot(a[0]-b[0],a[1]-b[1]) < 3 && Math.hypot(p[0]-q[0],p[1]-q[1]) > 7) return null
    }
  }
  const radius=Math.min(78,Math.max(21,size*.22))
  function warp(point) {
    const [x,y]=transform(point,m)
    let weights=0, sumX=0, sumY=0
    for(let j=0;j<pair.length;j++){
      let nearest=null, nearestIndex=0
      for (let i=1;i<SAMPLE_COUNT;i++) {
        const here=projection(x,y,mapped[j][i-1],mapped[j][i])
        if (!nearest || here.d<nearest.d) { nearest=here; nearestIndex=i }
      }
      if (nearest.d>=radius) continue
      const u=(nearestIndex-1+nearest.t)/(SAMPLE_COUNT-1)
      const dest=pointAt(targets[j].curve,u)
      const w=1/Math.max(.05,nearest.d)**2
      const f=1-nearest.d/radius
      const smoothing=f*f*(3-2*f)
      weights+=w
      sumX+=w*(dest[0]-nearest.x)*smoothing
      sumY+=w*(dest[1]-nearest.y)*smoothing
    }
    return weights?[x+sumX/weights,y+sumY/weights]:[x,y]
  }
  const strokes=[], features=new Map()
  const anchors = pair.map((s,j)=>({id:entry.subject.strokes[s.index].id,originalIndex:j}))
  for (const [index, stroke] of entry.subject.strokes.entries()) {
    let intervals=[[0,1]]
    const j=pair.findIndex(s=>s.index===index)
    let feature
    if (stroke.feature) {
      if(!features.has(stroke.feature)) features.set(stroke.feature,{name:stroke.feature,paths:[],addedPaths:[]})
      feature=features.get(stroke.feature)
    }
    if (j>=0) {
      // Keep the two player's paths in their own locked layer. Render only the
      // missing portion of each assigned contour, even for partial-arc matches.
      intervals=[[0,pair[j].from],[pair[j].to,1]]
      if(feature) feature.paths.push(original[j].p)
    }
    for (const [lo,hi] of intervals) {
      if (hi<=lo) continue
      const curve=entry.curves[index]
      const part=curve.length ? sliceCurve(curve,lo,hi) : [stroke.p[0]]
      // Straight spans near an anchor still need an intermediate vertex so a
      // local joint offset doesn't move the entire opposing edge.
      const path=[]
      for(let i=0;i<part.length;i++){
        if(i) {
          const a=part[i-1], b=part[i], n=Math.ceil(Math.hypot(b[0]-a[0],b[1]-a[1])*Math.hypot(m.a,m.b)/12)
          for(let k=1;k<n;k++) path.push(warp([a[0]+(b[0]-a[0])*k/n,a[1]+(b[1]-a[1])*k/n]))
        }
        path.push(warp(part[i]))
      }
      if(path.some(([x,y])=>x<2 || y<2 || x>WIDTH-2 || y>HEIGHT-2)) return null
      const p=path.map(([x,y])=>[Math.round(x*2)/2,Math.round(y*2)/2])
      strokes.push({c:'#423d4b',p})
      if(feature){feature.paths.push(p);feature.addedPaths.push(p)}
    }
  }
  const {id,name,anatomy}=entry.subject
  const result = {subject:{id,name,anatomy},strokes,features:[...features.values()],anchors,fitScore:Math.max(0,1-fit.cost/1.3)}
  if (fit.port) result.connection = warp(fit.port.at)
  return result
}

export function chooseComposition(original, catalog=subjects) {
  if (!Array.isArray(original) || original.length!==2 || original.some(s=>!s?.p?.length)) return null
  const targets=original.map(s=>{
    const curve=pathInfo(s.p), points=sample(curve)
    return {curve,points,length:curve.length,...moments(points)}
  })
  if(targets.some(t=>t.length<12 || t.length>1600 || t.energy<60)) return null
  // Keep a bounded shortlist per subject for the more expensive joint warp
  // and exact screen-bounds check. A bad fit deliberately yields no scaffold.
  const shortlist=[]
  for(const subject of catalog){
    const entry=catalogEntry(subject), ranked=[]
    for(const a of entry.choices) for(const b of entry.choices) {
      if(a.index===b.index) continue
      for(const mirror of [1,-1]){
        const fit=matchPair(entry,a,b,targets,mirror)
        if(fit) ranked.push(fit)
      }
    }
    ranked.sort((a,b)=>a.cost-b.cost)
    shortlist.push(...ranked.slice(0,4))
  }
  shortlist.sort((a,b)=>a.cost-b.cost)
  for(const fit of shortlist){
    const result=realize(fit,targets,original)
    if(result) return result
  }
  return null
}

// A scene port is a physical interaction, stated in the subject's local
// coordinates. Unlike a second outline match it permits the player to choose
// a freeform steam, spray, trail or wave. direction is the outward tangent.
const scenePorts = {
  elephant:[
    {at:[338,100], direction:[.65,-.76], name:'象鼻喷出的水流'}
  ],
  teapot:[
    {at:[72,105], direction:[0,-1], name:'壶嘴冒出的蒸汽'},
    {at:[67,110], direction:[-.68,.73], name:'从壶嘴倒出的茶水'}
  ],
  whale:[
    {at:[101,70], direction:[-.75,-.66], name:'鲸鱼喷出的水花'},
    {at:[165,64], direction:[.75,-.66], name:'鲸鱼喷出的水花'}
  ],
  snail:[
    {at:[38,211], direction:[-1,.08], name:'蜗牛尾后拖出的痕迹'}
  ],
  umbrella:[
    {at:[55,153], direction:[-.18,.98], name:'从伞尖垂下的雨线'},
    {at:[345,153], direction:[.18,.98], name:'从伞尖垂下的雨线'}
  ],
  sailboat:[{at:[196,244], name:'托住船底的海浪', floor:true}],
  duck:[{at:[163,253], name:'鸭蹼下的岸线', floor:true}],
  rabbit:[{at:[157,241], name:'兔子脚下的土坡', floor:true}]
}

function sceneMatrix(source, target, port, contact, mirror) {
  // Keep the main trace dominant. A projected point on the scene line has
  // lower leverage and can leave a small physical gap bridged below.
  const n = SAMPLE_COUNT, w = 5, k = n*w/(n+w)
  const dx=(source.x-port[0])*mirror, dy=source.y-port[1]
  const du=target.x-contact[0], dv=target.y-contact[1]
  let dot = k*(dx*du+dy*dv), cross=k*(dx*dv-dy*du)
  for(let i=0;i<n;i++){
    const [x,y]=source.centered[i], [u,v]=target.centered[i]
    dot += mirror*x*u+y*v
    cross += mirror*x*v-y*u
  }
  const energy=source.energy+k*(dx*dx+dy*dy)
  if(energy<1) return null
  const cos=dot/energy, sin=cross/energy, angle=Math.abs(Math.atan2(sin,cos))
  if(angle>.53) return null
  const a = mirror*cos, b = mirror*sin, c = -sin, d = cos
  const mx=(n*source.x+w*port[0])/(n+w), my=(n*source.y+w*port[1])/(n+w)
  const tx=(n*target.x+w*contact[0])/(n+w), ty=(n*target.y+w*contact[1])/(n+w)
  return {a,b,c,d,x:tx-a*mx-c*my, y:ty-b*mx-d*my}
}

function sceneSuitability(entry, port, secondary, contact, matrix) {
  const foot=transform(port.at,matrix)
  const dx=contact[0]-foot[0], dy=contact[1]-foot[1]
  const scale=Math.hypot(matrix.a,matrix.b), gap=Math.hypot(dx,dy)
  const sceneLength=secondary.length/scale
  if(sceneLength < 25 || sceneLength > 460) return null
  // Inverse similarity transform. floor/ray tests below use the orientation
  // of the drawing (including mirror), not a hard-coded screen direction.
  const det=matrix.a*matrix.d-matrix.b*matrix.c
  const localDelta = (x,y)=>[(matrix.d*x-matrix.c*y)/det,(-matrix.b*x+matrix.a*y)/det]
  const local=secondary.points.map(([x,y])=>localDelta(x-foot[0],y-foot[1]))
  let shapePenalty=0
  if(port.floor){
    if(gap > Math.max(5,8*scale)) return null
    const xx=local.map(p=>p[0]), yy=local.map(p=>p[1])
    const spanX=Math.max(...xx)-Math.min(...xx),spanY=Math.max(...yy)-Math.min(...yy)
    if(spanX<60 || spanX/sceneLength<.72 || spanY>spanX*.43+5) return null
    const lo=entry.bounds[0]-port.at[0], hi=entry.bounds[2]-port.at[0]
    // A shore or wave belongs at the feet/waterline; exclude lines through
    // the body and short unrelated lines lying wholly beyond the subject.
    if(local.some(([x,y])=>x>=lo && x<=hi && y < -10)) return null
    if(Math.min(...xx)>-15 || Math.max(...xx)<15) return null
    shapePenalty=.15*spanY/spanX
  } else {
    if(gap>Math.min(37,24*scale,secondary.length*.32+3)) return null
    const [ux,uy]=port.direction
    const out=local.map(([x,y])=>ux*x+uy*y)
    const side=local.map(([x,y])=>Math.abs(-uy*x+ux*y))
    const reach=Math.max(...out)
    if(reach<22 || reach/sceneLength < .36 || Math.min(...out)<-13) return null
    if(out.filter((v,i)=>v+9>=.32*side[i]).length < SAMPLE_COUNT*.83) return null
    // The center of a plume, trail or drip cannot pass through the animal.
    const toward=localDelta(dx,dy)
    if(toward[0]*ux+toward[1]*uy < -9) return null
    shapePenalty=.15*Math.max(...side)/reach
  }
  return {foot,gap,penalty:gap/(scale*(port.floor?8:30)+3)*.22 +shapePenalty}
}

export function chooseSingleAnchorScene(original, catalog=subjects) {
  if(!Array.isArray(original)||original.length!==2||original.some(s=>!s?.p?.length)) return null
  const targets=original.map(s=>{
    const curve=pathInfo(s.p), points=sample(curve)
    return {curve,points,length:curve.length,...moments(points)}
  })
  if(targets.some(t=>t.length<12 || t.length>1600 || t.energy<60)) return null
  const candidates=[]
  for(const subject of catalog){
    const ports=scenePorts[subject.id]
    if(!ports)continue
    const entry=catalogEntry(subject), [left,top,right,bottom]=entry.bounds
    for(const source of entry.choices){
      for(let j=0;j<2;j++){
        const target=targets[j], secondary=targets[1-j]
        for(const port of ports){
          const contacts=port.floor?[2,4,6,8,10]:[0,SAMPLE_COUNT-1]
          for(const index of contacts) for(const mirror of [1,-1]){
            const contact=secondary.points[index]
            const m=sceneMatrix(source,target,port.at,contact,mirror)
            if(!m)continue
            const scale=Math.hypot(m.a,m.b)
            const size=scale*Math.max(right-left,bottom-top)
            const ratio=target.length/(scale*source.length)
            if(size<125 || size>700 || ratio<.79 || ratio>1.27)continue
            // Avoid letting a short corner stand in for the user's main idea.
            if(target.length<size*.195)continue
            const scene=sceneSuitability(entry,port,secondary,contact,m)
            if(!scene)continue
            const mapped=source.points.map(p=>transform(p,m))
            const errors=mapped.map(([x,y],i)=>Math.hypot(x-target.points[i][0],y-target.points[i][1]))
            const tolerance=2.7+Math.min(.054*size,.115*target.length)
            const rms=Math.sqrt(errors.reduce((s,e)=>s+e*e,0)/SAMPLE_COUNT)
            if(rms>tolerance || Math.max(...errors)>1.8*tolerance)continue
            const cost=rms/tolerance + .28*Math.abs(Math.log(ratio)) +
              .18*(1-source.to+source.from)+scene.penalty
            if(cost>.96)continue
            candidates.push({entry,m,size,pair:[source],mapped:[mapped],cost,scene,port,contact,j})
          }
        }
      }
    }
  }
  candidates.sort((a,b)=>a.cost-b.cost)
  for(const fit of candidates.slice(0,40)){
    const {j,port,contact}=fit
    const plan=realize(fit,[targets[j]],[original[j]])
    if(!plan)continue
    plan.anchors[0].originalIndex=j
    plan.anchors.push({id:port.name,originalIndex:1-j})
    const portPoint = plan.connection
    delete plan.connection
    const gap = Math.hypot(portPoint[0] - contact[0], portPoint[1] - contact[1])
    const scale = Math.hypot(fit.m.a, fit.m.b)
    if (port.floor && gap > Math.max(5,8*scale)) continue
    if (!port.floor && gap > Math.min(37,24*scale,targets[1-j].length*.32+3)) continue
    const addedPaths=[]
    if(!port.floor && gap>2.5){
      const connector=[portPoint,contact].map(p=>p.map(v=>Math.round(v*2)/2))
      if(connector.some(([x,y])=>x<0||x>WIDTH||y<0||y>HEIGHT))continue
      plan.strokes.push({c:'#423d4b',p:connector})
      addedPaths.push(connector)
    }
    plan.features.push({name:port.name,paths:[original[1-j].p,...addedPaths],addedPaths})
    plan.subject.anatomy += port.name+'沿玩家的另一条曲线延伸。'
    return plan
  }
  return null
}
