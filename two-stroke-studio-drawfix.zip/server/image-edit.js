import sharp from 'sharp'

export const DEFAULT_IMAGE_MODEL = 'gpt-image-2.6-sunburst'
const EDIT_URL = 'https://api.openai.com/v1/images/edits'
const WIDTH = 800
const HEIGHT = 560
const EDIT_WIDTH = 1536
const EDIT_HEIGHT = 1024

// Fit the exact 10:7 drawing area into a standard image-edit size without stretching it.
const CROP = {left: 48, top: 8, width: 1440, height: 1008}
const TIMEOUT_MS = 240_000
const GUIDE_COLOR = '#1683e8'

const INSTRUCTIONS = [
  'Complete this two-stroke doodle game on the supplied page. Return exactly one finished drawing at the very same scale and position as the input.',
  'The two existing BLUE pen strokes are locked ink. Keep every blue pixel in place, with the same endpoints, shape and color. Do not draw any extra blue marks. Do not trace them in black.',
  'Look at the bends and endpoints. Choose the one familiar, concrete subject they most naturally suggest. Use BOTH blue strokes as recognizable structural parts, ideally long sections of its silhouette. New contours should meet the existing blue ink precisely. Do not draw a separate picture next to the lines.',
  'Make the subject unmistakable even as a tiny thumbnail. Use its characteristic outline and just one or two identifying details. A funny pose or expression is enough; avoid invented creatures and busy scenes. If the lines are very far apart, connect them visually through a single simple action between two immediately recognizable objects.',
  'Draw only the missing parts with a pure black uniform round-tipped pen, approximately the width of the blue lines. Use a handful of confident open or closed strokes with generous white gaps. Use thin outlines and tiny dot eyes as needed. Leave the rest of the page pure white. No panels, labels, lettering, borders, shading, filled silhouettes, brush texture, shadows or decorative marks.',
  'Return the drawing itself, completely inside the original drawing area, with the blue foundation still visible. Keep the camera fixed and the page uncropped.'
].join('\n')

function editError(message, status) {
  const error = new Error(message)
  error.status = status
  error.publicMessage = message
  return error
}

// The server validates submitted strokes before calling here. Keeping coordinates
// numeric also prevents any user-entered SVG markup from reaching the rasterizer.
function svgStroke(stroke, color) {
  const points = stroke.p
  for (const point of points) {
    if (point.length !== 2 || !point.every(Number.isFinite)) {
      throw editError('画板坐标无效。', 400)
    }
  }
  if (points.length === 1) {
    const [x, y] = points[0]
    return `<circle cx="${x}" cy="${y}" r="2.5" fill="${color}"/>`
  }
  const coordinates = points.map(([x, y]) => `${x},${y}`).join(' ')
  return `<polyline fill="none" stroke="${color}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" points="${coordinates}"/>`
}

async function renderInput(strokes, mask) {
  const background = mask
    ? '<path fill-rule="evenodd" fill="white" d="M0 0h1536v1024H0z M48 8h1440v1008H48z"/>'
    : '<rect width="100%" height="100%" fill="white"/>'
  const ink = strokes.map(stroke => svgStroke(stroke, mask ? 'white' : GUIDE_COLOR)).join('')
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${EDIT_WIDTH}" height="${EDIT_HEIGHT}">
    ${background}
    <svg x="${CROP.left}" y="${CROP.top}" width="${CROP.width}" height="${CROP.height}" viewBox="0 0 ${WIDTH} ${HEIGHT}" overflow="hidden">${ink}</svg>
  </svg>`
  return sharp(Buffer.from(svg)).ensureAlpha().png().toBuffer()
}

function serviceError(status, code) {
  if (code === 'content_policy_violation' || code === 'moderation_blocked') {
    return editError('OpenAI 未能处理这次图像编辑。可以换两笔再尝试。', 422)
  }
  if (code === 'billing_hard_limit_reached' || code === 'insufficient_quota') {
    return editError('OpenAI 图像接口的可用额度不足，请站长检查 API 账单。', 503)
  }
  if (status === 401) return editError('OpenAI 拒绝了服务器使用的 API Key，请站长检查密钥。', 503)
  if (status === 403 || code === 'model_not_found') {
    return editError('当前 OpenAI 项目无法访问配置的图像模型，请站长检查模型权限和 OPENAI_IMAGE_MODEL。', 503)
  }
  if (status === 429) return editError('OpenAI 图像接口当前限流，请稍后再试。', 429)
  return editError('OpenAI 图像编辑请求失败，请稍后再试。', 502)
}

async function normalizeEdit(encoded) {
  if (typeof encoded !== 'string' || !encoded.length || encoded.length > 24_000_000) {
    throw editError('OpenAI 未返回可读取的 PNG。', 502)
  }
  const pipeline = sharp(Buffer.from(encoded, 'base64'), {limitInputPixels: EDIT_WIDTH * EDIT_HEIGHT})
  const metadata = await pipeline.metadata()
  if (metadata.format !== 'png' || metadata.width !== EDIT_WIDTH || metadata.height !== EDIT_HEIGHT) {
    throw editError('生成图片的画幅不符，无法和原始笔画对齐。', 502)
  }
  const {data, info} = await pipeline
    .extract(CROP)
    .flatten({background: 'white'})
    .toColourspace('srgb')
    .removeAlpha()
    .resize(WIDTH, HEIGHT, {fit: 'fill'})
    .raw()
    .toBuffer({resolveWithObject: true})
  return {pixels: data, width: info.width, height: info.height, channels: info.channels}
}

export async function createDoodleEdit(original, {
  apiKey = process.env.OPENAI_API_KEY,
  model = process.env.OPENAI_IMAGE_MODEL || DEFAULT_IMAGE_MODEL,
  signal,
  fetchImpl = fetch
} = {}) {
  if (!apiKey) throw editError('请在服务端设置 OPENAI_API_KEY。', 503)
  const timeout = AbortSignal.timeout(TIMEOUT_MS)
  const requestSignal = signal ? AbortSignal.any([timeout, signal]) : timeout
  requestSignal.throwIfAborted()
  const [image, mask] = await Promise.all([renderInput(original, false), renderInput(original, true)])
  const form = new FormData()
  form.set('model', model)
  form.set('prompt', INSTRUCTIONS)
  form.set('size', `${EDIT_WIDTH}x${EDIT_HEIGHT}`)
  form.set('quality', 'high')
  form.set('output_format', 'png')
  form.set('n', '1')
  form.set('image', new Blob([image], {type: 'image/png'}), 'drawing.png')
  form.set('mask', new Blob([mask], {type: 'image/png'}), 'protected-lines.png')

  try {
    // One upstream request per round. Never retry or follow an HTTP redirect.
    const response = await fetchImpl(EDIT_URL, {
      method: 'POST', redirect: 'error',
      headers: {Authorization: `Bearer ${apiKey}`}, body: form, signal: requestSignal
    })
    const result = await response.json().catch(() => null)
    if (!response.ok) throw serviceError(response.status, result?.error?.code)
    return await normalizeEdit(result?.data?.[0]?.b64_json)
  } catch (error) {
    if (signal?.aborted) throw signal.reason
    if (timeout.aborted) throw editError('本次图像编辑等待超时，服务器已停止等待。', 504)
    if (error?.status) throw error
    throw editError('图像服务连接中断或返回数据无法读取，请稍后再试。', 502)
  }
}
