import sharp from 'sharp'

// R/G encode the playback position; B is the opacity of the final ink.
// An opaque PNG avoids browser premultiplication changing the stored bytes.
export async function makeRevealMap(strokes, inkAlpha, width, height) {
  const count = width * height
  const order = new Uint16Array(count)
  const queue = new Int32Array(count)
  let end = 0
  let distance = 0
  const lengths = strokes.map(({p}) => p.reduce((sum, point, i) =>
    i === 0 ? 0 : sum + Math.hypot(point[0] - p[i-1][0], point[1] - p[i-1][1]), 0))
  const total = lengths.reduce((sum, length) => sum + Math.max(length, 1), 0)
  function seed(x, y, position) {
    const i = Math.round(y) * width + Math.round(x)
    if (order[i]) return
    order[i] = 1 + Math.min(65534, Math.round(position / total * 65534))
    queue[end++] = i
  }
  for (const [index, {p}] of strokes.entries()) {
    seed(...p[0], distance)
    for (let i = 1; i < p.length; i++) {
      const [x, y] = p[i-1]
      const dx = p[i][0] - x, dy = p[i][1] - y
      const length = Math.hypot(dx, dy)
      const steps = Math.ceil(length)
      for (let j = 1; j <= steps; j++) {
        const t = j / steps
        seed(x + dx*t, y + dy*t, distance + length*t)
      }
      distance += length
    }
    distance += Math.max(1 - lengths[index], 0)
  }
  // Extend the nearest centerline sample to the full ink width. This keeps dots,
  // tapered outlines and the final artwork, including tiny disconnected details.
  let head = 0
  function visit(i, rank) {
    if (!order[i]) {
      order[i] = rank
      queue[end++] = i
    }
  }
  while (head < end) {
    const i = queue[head++], rank = order[i], x = i % width
    if (x > 0) visit(i - 1, rank)
    if (x + 1 < width) visit(i + 1, rank)
    if (i >= width) visit(i - width, rank)
    if (i + width < count) visit(i + width, rank)
  }
  const rgb = Buffer.alloc(count * 3)
  for (let i = 0; i < count; i++) {
    if (!inkAlpha[i]) continue
    rgb[i * 3] = order[i] >> 8
    rgb[i * 3 + 1] = order[i] & 255
    rgb[i * 3 + 2] = inkAlpha[i]
  }
  const png = await sharp(rgb, {raw:{width, height, channels:3}}).png().toBuffer()
  return 'data:image/png;base64,' + png.toString('base64')
}
