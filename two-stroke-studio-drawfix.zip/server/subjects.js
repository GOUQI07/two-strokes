// Each centerline is a separate pen gesture. Shared endpoints allow the two
// player strokes to take the place of meaningful pieces of the drawing.
function samplePath(d) {
  const tokens = d.match(/[MLQCZ]|-?\d+(?:\.\d+)?/g)
  let i = 0
  const read = () => [Number(tokens[i++]), Number(tokens[i++])]
  const distance = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1])
  const mix = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]
  const points = []
  while (i < tokens.length) {
    const command = tokens[i++]
    if (command === 'M') { points.push(read()); continue }
    const from = points.at(-1)
    if (command === 'Z') { points.push([...points[0]]); continue }
    const n = {L: 1, Q: 2, C: 3}[command]
    if (!n) throw new Error('Unknown drawing command ' + command)
    const controls = [from, ...Array.from({length:n}, read)]
    const length = controls.slice(1).reduce((s, p, j) => s + distance(p, controls[j]), 0)
    const steps = Math.max(1, Math.ceil(length / 3.5))
    for (let j = 1; j <= steps; j++) {
      let curve = controls
      const t = j / steps
      while (curve.length > 1) curve = curve.slice(1).map((p, k) => mix(curve[k], p, t))
      points.push(curve[0])
    }
  }
  return points
}

function line(id, d, anchor = false, feature) {
  return {id, p:samplePath(d), ...(anchor && {anchor}), ...(feature && {feature})}
}

function ring(id, x, y, radius, feature) {
  const p = Array.from({length:25}, (_, i) => {
    const theta = i * Math.PI / 12
    return [x + radius * Math.cos(theta), y + radius * Math.sin(theta)]
  })
  return {id, p, ...(feature && {feature})}
}

export const subjects = [
  {
    id:'elephant', name:'小象',
    anatomy:'圆背和柱形腿，头旁有一只宽大的扇耳，长鼻从额头一直伸出并上卷。',
    strokes:[
      line('back', 'M69 170 C51 113 82 77 129 75 Q169 69 204 80', true),
      line('forehead', 'M204 80 C229 58 258 64 272 87 Q280 100 281 123', true),
      line('trunk-top', 'M281 123 C294 151 318 142 318 116 C317 101 328 94 338 100', true, 'curled-trunk'),
      line('trunk-return', 'M338 100 C349 139 330 180 302 178 Q275 178 256 152', true, 'curled-trunk'),
      line('chest-leg', 'M256 152 Q252 172 235 182 L237 224 Q238 232 229 233 L212 233 Q205 233 205 225 L201 195', true),
      line('belly-leg', 'M201 195 Q163 204 132 196 L126 225 Q125 233 117 233 L101 233 Q93 233 94 224 L95 192 Q76 186 69 170', true),
      line('ear', 'M209 93 C185 74 155 85 161 116 C167 150 181 169 197 163 Q211 157 214 129', true, 'fan-ear'),
      line('tail', 'M65 143 Q46 159 52 178', false),
      line('tuft', 'M52 176 Q42 180 46 194 Q57 191 52 176', false),
      ring('eye',244,112,2.3)
    ]
  },
  {
    id:'rabbit', name:'兔子',
    anatomy:'侧坐的小兔有两只细长、略向不同方向倾斜的耳朵，圆棉球尾和收起的粗后腿。',
    strokes:[
      line('face', 'M70 168 Q84 132 121 117 L137 111', true),
      line('front-ear', 'M137 111 C114 89 98 51 109 37 C127 18 152 73 158 104', true, 'long-ears'),
      line('rear-ear', 'M158 104 C156 63 159 23 175 21 C194 19 192 74 176 113', true, 'long-ears'),
      line('ear-fold', 'M164 88 Q165 54 174 41'),
      line('back', 'M176 113 Q190 122 193 137 C229 109 287 119 302 161 Q308 172 308 180', true),
      line('bobtail', 'M308 180 C320 159 341 167 338 185 Q349 203 332 213 Q318 222 307 213', false, 'cotton-tail'),
      line('hind-foot', 'M307 213 C298 237 272 242 239 241 L188 241 Q178 241 179 234 Q182 226 205 223', true),
      line('haunch', 'M205 223 C181 208 190 177 216 169', true, 'haunch'),
      line('belly', 'M186 227 Q168 231 152 225'),
      line('forepaw', 'M152 225 Q152 235 144 235 L115 235 Q104 234 111 226 Q119 219 130 218 L127 199'),
      line('cheek', 'M127 199 Q95 206 76 183 Q66 179 70 168', true),
      line('nose', 'M71 169 Q78 165 83 169 Q81 175 74 177'),
      ring('eye',115,156,2.7)
    ]
  },
  {
    id:'whale', name:'鲸鱼',
    anatomy:'圆胖的鲸头，背顶喷出一股分叉的水柱；尾柄上翘，末端有两叶尾鳍，胸鳍向下摆。',
    strokes:[
      line('forehead', 'M46 171 C40 133 80 108 128 111', true),
      line('back', 'M128 111 C163 109 194 119 218 138 Q251 160 276 128', true),
      line('inner-fluke', 'M276 128 Q260 102 266 75 Q292 76 310 103', true, 'paired-flukes'),
      line('outer-fluke', 'M310 103 Q329 79 359 86 Q346 125 309 131', true, 'paired-flukes'),
      line('tail-belly', 'M309 131 C291 178 256 213 195 222', true),
      line('pectoral-fin', 'M195 222 Q200 235 192 243 Q161 233 143 208', false),
      line('chin', 'M158 224 C102 227 51 205 46 171', true),
      line('smile', 'M48 177 Q68 186 85 177'),
      line('fountain-left', 'M129 100 C128 78 111 59 102 72 C91 76 86 64 93 56 C107 40 128 54 134 80', false, 'blowhole-spout'),
      line('fountain-right', 'M134 80 C142 53 163 47 171 60 Q178 74 162 75 C151 67 143 83 138 100', false, 'blowhole-spout'),
      ring('eye',89,156,2.8)
    ]
  },
  {
    id:'snail', name:'蜗牛',
    anatomy:'大圆螺壳里有清楚的盘旋线，软身体贴着地面拖成长尾，头上两根触角各顶着一只眼睛。',
    strokes:[
      line('shell-left', 'M67 156 C48 111 74 72 116 63', true, 'round-shell'),
      line('shell-top', 'M116 63 C168 45 214 81 217 135', true, 'round-shell'),
      line('shell-right', 'M217 135 C222 168 195 199 159 204', true),
      line('shell-base', 'M159 204 C116 210 82 186 67 156', true),
      line('spiral', 'M83 157 C72 122 91 90 126 85 C163 78 192 102 192 132 C192 159 171 177 147 176 C124 174 110 159 114 139 C117 121 136 115 149 123 C159 131 155 145 146 146 Q135 146 136 136', false, 'shell-spiral'),
      line('neck', 'M211 168 C235 165 235 134 254 126', true),
      line('head-foot', 'M254 126 C275 112 296 125 300 145 C304 165 290 176 278 185 C265 195 270 208 298 213', true),
      line('foot', 'M298 213 C267 234 221 229 174 230 C122 230 76 239 38 211 Q65 215 82 183', true),
      line('left-stalk', 'M254 126 Q250 106 244 97', false, 'eye-stalks'),
      line('right-stalk', 'M283 124 Q293 103 302 96', false, 'eye-stalks'),
      ring('left-eye',242,91,6,'eye-stalks'),
      ring('right-eye',306,91,6,'eye-stalks'),
      line('smile', 'M281 158 Q292 161 298 150')
    ]
  },
  {
    id:'teapot', name:'茶壶',
    anatomy:'鼓起的壶肚、一侧朝上弯的壶嘴、另一侧中空的大把手。壶盖在最上面，有一个小钮。',
    strokes:[
      line('shoulder', 'M151 112 Q129 126 125 151', true),
      line('spout-top', 'M125 151 C105 150 98 127 81 111', true, 'pointing-spout'),
      line('spout-mouth', 'M81 111 Q65 117 63 110 Q63 103 84 103 Q91 106 81 111', false, 'pointing-spout'),
      line('spout-base', 'M64 113 C76 152 94 183 124 189', true, 'pointing-spout'),
      line('base', 'M124 189 Q131 221 164 234 Q200 245 235 233', true),
      line('body-right', 'M235 233 C259 216 271 197 269 172 C270 146 258 125 243 113', true),
      line('handle-outside', 'M262 136 C301 96 341 122 326 161 Q310 194 263 201', true, 'open-handle'),
      line('handle-inside', 'M268 148 C294 123 314 128 306 151 Q298 171 268 183', true, 'open-handle'),
      line('lid-left', 'M146 110 Q161 90 188 88', false, 'lid-and-knob'),
      line('knob', 'M188 88 C179 74 185 65 195 66 C205 66 209 77 202 88', false, 'lid-and-knob'),
      line('lid-right', 'M202 88 Q232 90 248 110', false, 'lid-and-knob'),
      line('rim', 'M248 110 Q201 125 146 110', true, 'lid-and-knob')
    ]
  },
  {
    id:'sailboat', name:'帆船',
    anatomy:'一根桅杆把两面受风鼓起的三角帆分开，下方是两端上翘的船身，桅顶挂一面小旗。',
    strokes:[
      line('mast', 'M198 50 L198 205', true, 'mast'),
      line('pennant', 'M198 50 L198 34 Q216 32 239 38 Q220 47 198 51'),
      line('large-sail-luff', 'M184 66 Q147 131 82 181', true, 'sails'),
      line('large-sail-foot', 'M82 181 Q136 191 184 181', true, 'sails'),
      line('large-sail-edge', 'M184 181 L184 66', true, 'sails'),
      line('small-sail-edge', 'M213 82 Q270 129 300 184', true, 'sails'),
      line('small-sail-return', 'M300 184 Q250 179 213 182 L213 82', false, 'sails'),
      line('deck', 'M56 199 Q173 211 338 195', true, 'hull'),
      line('bow', 'M338 195 Q324 218 296 234', true, 'hull'),
      line('keel', 'M296 234 Q190 252 91 235 Q71 222 56 199', true, 'hull'),
      ring('porthole-1',130,220,4),
      ring('porthole-2',159,221,4)
    ]
  },
  {
    id:'duck', name:'鸭子',
    anatomy:'一只侧身站立的鸭子，扁而宽的鸭嘴前端略翘，尾羽上扬，身下有两只向前伸的蹼足。',
    strokes:[
      line('neck-back', 'M97 151 Q121 140 145 138 Q167 134 172 104', true),
      line('round-head', 'M172 104 C171 70 191 46 219 48 Q257 46 265 89', true),
      line('bill-top', 'M265 89 Q285 92 304 82 Q311 82 306 91 Q296 102 271 107', true, 'duck-bill'),
      line('bill-bottom', 'M271 107 Q287 109 302 102 Q291 118 264 119', false, 'duck-bill'),
      line('breast', 'M264 119 Q257 135 242 140 C248 164 249 194 198 216', true),
      line('belly', 'M198 216 C143 233 99 213 80 187 Q74 177 75 157', true),
      line('tail', 'M75 157 L54 133 Q77 134 97 151', true, 'raised-tail'),
      line('wing', 'M109 157 Q133 161 159 144 C181 131 192 148 181 169 C168 197 133 199 109 157', true),
      line('back-foot', 'M132 220 L129 240 L117 250 Q128 250 134 247 L129 254 Q143 251 157 246 Q158 241 145 241 L146 222', false, 'webbed-feet'),
      line('front-foot', 'M175 221 L180 237 L169 245 Q180 244 185 242 L182 249 Q196 246 210 242 Q209 237 196 238 L191 218', false, 'webbed-feet'),
      ring('eye',236,81,2.7)
    ]
  },
  {
    id:'umbrella', name:'雨伞',
    anatomy:'张开的半球形伞面，下沿分成四个连续的波瓣，几根伞骨从顶点散下；伞柄底部弯成 J 形。',
    strokes:[
      line('canopy-left', 'M55 153 C83 100 138 64 200 63', true, 'canopy'),
      line('canopy-right', 'M200 63 C269 61 322 107 345 153', true, 'canopy'),
      line('scallops-left', 'M55 153 Q86 133 119 152 Q154 132 192 152', true, 'scalloped-edge'),
      line('scallops-right', 'M192 152 Q233 132 271 152 Q308 130 345 153', true, 'scalloped-edge'),
      line('rib-left', 'M200 64 Q149 90 119 152'),
      line('rib-center', 'M200 64 Q194 111 192 152'),
      line('rib-right', 'M200 64 Q248 91 271 152'),
      line('finial', 'M200 62 L202 49'),
      line('shaft', 'M192 152 L186 225', true, 'hook-handle'),
      line('hook', 'M186 225 C184 254 149 256 140 235 Q136 223 143 222 Q148 221 151 233 C158 245 173 240 175 226', true, 'hook-handle')
    ]
  }
]
