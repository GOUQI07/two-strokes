// Each reference layout requires a specific arrangement of both original lines.
const W = 800, H = 560
const pen = p => ({c:'#423d4b', p})
const dist = (a,b) => Math.hypot(a[0]-b[0], a[1]-b[1])
const length = p => p.slice(1).reduce((sum,q,i) => sum + dist(q,p[i]),0)
const bounds = p => ({
  left:Math.min(...p.map(q=>q[0])), right:Math.max(...p.map(q=>q[0])),
  top:Math.min(...p.map(q=>q[1])), bottom:Math.max(...p.map(q=>q[1]))
})
const group = (name,...paths) => ({name,paths})
function curve(a,b,c,steps=20) {
  return Array.from({length:steps+1},(_,i)=>{
    const t=i/steps, s=1-t
    return [s*s*a[0]+2*t*s*b[0]+t*t*c[0],s*s*a[1]+2*t*s*b[1]+t*t*c[1]]
  })
}
function planned(id,name,anatomy,lines,features) {
  if (!lines.every(p=>p.every(([x,y])=>x>=0 && x<=W && y>=0 && y<=H))) return null
  return {subject:{id,name,anatomy},strokes:lines.map(pen),features}
}

export function sailPlan(original) {
  for (const mastIndex of [0,1]) {
    const mast=original[mastIndex].p, sail=original[1-mastIndex].p
    const [top,foot]=[mast[0],mast.at(-1)].sort((a,b)=>a[1]-b[1])
    const h=foot[1]-top[1], b=bounds(sail)
    if (h<85 || Math.abs(foot[0]-top[0])>h*.24 || length(mast)>dist(top,foot)*1.12) continue
    const [tip,clew]=[sail[0],sail.at(-1)].sort((a,b)=>a[1]-b[1])
    const side = (b.left+b.right)/2 < top[0] ? -1 : 1
    const span = side===-1 ? top[0]-b.left : b.right-top[0]
    if (span < h*.5 || span > h*2 || b.right-b.left<h*.28 ||
        (side===-1?b.right>top[0]+8:b.left<top[0]-8) ||
        Math.abs(tip[1]-top[1])>h*.40 || b.bottom>foot[1]-6 ||
        b.top<top[1]-h*.36 || clew[1]-tip[1]<h*.33) continue
    // Require the open player-supplied sail to enclose visible area after
    // closing its endpoints. This avoids using a straight line as a flat sail.
    let area=0
    for (let i=0;i<sail.length;i++){
      const a=sail[i],z=sail[(i+1)%sail.length]; area+=a[0]*z[1]-z[0]*a[1]
    }
    if (Math.abs(area)/2 < span*h*.045) continue
    const oppositeSpace = side<0 ? W-foot[0]-20 : foot[0]-20
    const jibWidth=Math.min(h*.51,oppositeSpace-15)
    if(jibWidth<h*.22) continue
    const jibTop=[top[0]+(foot[0]-top[0])*.11,top[1]+h*.11]
    const jibOuter=[foot[0]-side*jibWidth,foot[1]-h*.16]
    const jibInner=[foot[0]+(top[0]-foot[0])*.13,foot[1]-h*.13]
    const jib=[jibTop,jibOuter,jibInner]
    const nearSide=side<0 ? b.left : b.right
    const bow=[nearSide+side*12,foot[1]]
    const stern=[jibOuter[0]-side*12,foot[1]]
    const beam=Math.abs(stern[0]-bow[0]), keel=Math.min(54,beam*.115)
    const hull=[[bow[0],bow[1]],[bow[0]-side*beam*.12,bow[1]+keel],[stern[0]+side*beam*.09,stern[1]+keel],stern,bow]
    const edge=[tip,clew], rig=[tip,top]
    const rigFoot=[clew,[foot[0]+(top[0]-foot[0])*.17,foot[1]-h*.17]]
    const res=planned('sailboat','帆船','一侧大三角帆、一侧小前帆、竖立的桅杆、两端上翘的船身。两条原线分别构成帆的边缘和桅杆。',[edge,rig,jib,rigFoot,hull],
      [group('三角帆',sail,edge),group('侧帆',jib),group('船身',hull)])
    if(res)return res
  }
  return null
}

function jellyfishPlan(original) {
  const paths=original.map(s=>s.p)
  const starts=paths.map(p=>p[0][1]<=p.at(-1)[1]?p[0]:p.at(-1)).sort((a,b)=>a[0]-b[0])
  const [a,b]=starts, gap=b[0]-a[0], mid=(a[0]+b[0])/2, y=(a[1]+b[1])/2
  if(gap<27 || gap>275 || Math.abs(a[1]-b[1])>Math.min(gap*.4,48))return null
  if(paths.some(p=>bounds(p).top<y-32 || bounds(p).bottom<y+50))return null
  const rx=Math.max(64,gap*.72), ry=rx*.73
  const left=[mid-rx,y+2], right=[mid+rx,y+2]
  const dome=Array.from({length:41},(_,i)=>{
    const angle=Math.PI*(1-i/40)
    return [mid+rx*Math.cos(angle),y+2-ry*Math.sin(angle)]
  })
  const edges=[left,a,[(a[0]+b[0])/2,y],b,right], scallop=[]
  for(let i=0;i<edges.length-1;i++){
    const p=edges[i],q=edges[i+1]
    const arc=curve(p,[(p[0]+q[0])/2,Math.max(p[1],q[1])+Math.min(20,(q[0]-p[0])*.5)],q)
    scallop.push(...arc.slice(i?1:0))
  }
  const feeler=curve([mid,y],[mid+rx*.45,y+ry*.52],[mid+rx*.12,y+ry*.79])
    .concat(curve([mid+rx*.12,y+ry*.79],[mid-rx*.18,y+ry*1.04],[mid+rx*.02,y+ry*1.29]).slice(1))
  const rib=curve([mid-rx*.56,y-ry*.66],[mid-rx*.68,y-ry*.6],[mid-rx*.76,y-ry*.4])
  return planned('jellyfish','水母','半圆钟罩，下缘呈扇贝波浪；两条原始笔画都从罩子边缘垂下，成为触手。',[dome,scallop,feeler,rib],
    [group('钟形伞盖',dome),group('波浪裙边',scallop),group('下垂的触手',...paths,feeler)])
}
// A high reed, descending tube, rounded bow and short upturned bell distinguish
// a saxophone outline from a generic wavy stroke. Work in arc length so touch
// reporting frequency, pen lifts and the direction of drawing do not affect it.
function saxophone(path) {
  const b = bounds(path)
  const w = b.right - b.left, h = b.bottom - b.top
  if (w < 38 || h < 65 || w / h < .24 || w / h > 1.35) return null
  const points = path[0][1] <= path.at(-1)[1] ? path : [...path].reverse()
  const reed = points[0], bell = points.at(-1)
  const lift = (b.bottom - bell[1]) / h
  if (reed[1] > b.top + h * .12 || lift < .105 || lift > .64 ||
      Math.abs(bell[0] - reed[0]) < w * .22) return null

  const distances = [0]
  for (let i = 1; i < points.length; i++) {
    distances.push(distances[i - 1] + dist(points[i - 1], points[i]))
  }
  const total = distances.at(-1)
  if (total > (w + h) * 1.6) return null
  let segment = 1
  const axis = Array.from({length:41}, (_, i) => {
    const d = i * total / 40
    while (segment < points.length - 1 && distances[segment] <= d) segment++
    const a = points[segment - 1], z = points[segment]
    const t = (d - distances[segment - 1]) / (distances[segment] - distances[segment - 1] || 1)
    return [a[0] + (z[0] - a[0]) * t, a[1] + (z[1] - a[1]) * t]
  })
  const bottom = axis.reduce((deepest, q, i) => q[1] > axis[deepest][1] ? i : deepest, 0)
  if (bottom < 13 || bottom > 36 || axis[37][1] < bell[1] + h * .035) return null
  let backtracking = 0
  for (let i = 1; i < axis.length; i++) {
    const dy = axis[i][1] - axis[i - 1][1]
    backtracking += Math.max(0, i <= bottom ? -dy : dy)
  }
  if (backtracking > h * .12) return null

  const side = Math.sign(bell[0] - reed[0])
  const tube = Math.max(5, Math.min(w * .14, h * .095, 18))
  const normal = axis.map((_, i) => {
    const a = axis[Math.max(0, i - 1)], z = axis[Math.min(40, i + 1)]
    const d = dist(a, z) || 1
    return [side * (z[1] - a[1]) / d, side * (a[0] - z[0]) / d]
  })
  const edge = axis.map(([x,y], i) => {
    const t = i / 40
    const width = tube * (.28 + .9*t + 1.8 * Math.pow(t, 7))
    return [x + normal[i][0] * width, y + normal[i][1] * width]
  })
  const ring = (center, u, a, b) => Array.from({length:29}, (_, i) => {
    const theta = i * Math.PI / 14
    return [center[0] + a*Math.cos(theta)*u[0] - b*Math.sin(theta)*u[1],
      center[1] + a*Math.cos(theta)*u[1] + b*Math.sin(theta)*u[0]]
  })
  const bellCenter = [(edge[40][0]+bell[0])/2, (edge[40][1]+bell[1])/2]
  const rim = ring(bellCenter, normal[40], dist(edge[40], bell)/2 + 2, tube*.43)
  // A bent mouthpiece and the keyed rod give the long hook its identity.
  const step = dist(reed,axis[2]) || 1
  const ux = (reed[0]-axis[2][0])/step, uy = (reed[1]-axis[2][1])/step
  const outward = Math.abs(ux)>.38 ? Math.sign(ux) : -side
  const bend = [reed[0]+ux*tube*1.5, reed[1]+uy*tube*1.5]
  const neck = [reed[0]+outward*tube*1.9, reed[1]-tube*.56]
  const mouth = [neck[0]+outward*tube*1.03, neck[1]+tube*.68]
  const lower = [neck[0]+outward*tube*.03, neck[1]+tube*.33]
  const reedCap = [...curve(reed,bend,neck),mouth,lower,...curve(lower,[bend[0],bend[1]+tube*.44],edge[0]).slice(1)]
  const rodPoint = i => [edge[i][0]+normal[i][0]*tube*.64,edge[i][1]+normal[i][1]*tube*.64]
  const rod = [edge[12],...axis.slice(12,26).map((_,index)=>rodPoint(12+index)),edge[25]]
  const keyRadius = Math.max(3, Math.min(tube*.32,total*.018))
  const keys = [14,18,22].map(i => ring(rodPoint(i),normal[i],keyRadius,keyRadius))
  return {box:b, edge, reedCap, rim, rod, keys}
}

function saxophonePair(original) {
  const instruments = original.map(stroke => saxophone(stroke.p))
  if (instruments.some(item => !item)) return null
  const [a,b] = instruments.map(item=>item.box).sort((a,b)=>a.left-b.left)
  const size = Math.max(a.right-a.left,b.right-b.left)
  if (b.left < a.right + 5 || b.left-a.right > size*1.6 ||
      Math.abs(a.bottom-b.bottom) > Math.min(a.bottom-a.top, b.bottom-b.top)*.38) return null
  const lines = instruments.flatMap(s=>[s.edge,s.rim,s.reedCap,s.rod,...s.keys])
  return planned('sax-duet','萨克斯二重奏','两条向上回钩的原线各是乐器的一面管壁，从吹嘴绕过弯管接到外张的喇叭口。',
    lines,[group('弯管',...original.map(s=>s.p)),group('喇叭口',...instruments.map(s=>s.rim))])
}
function glassesPlan(original) {
  const parts=original.map(s=>bounds(s.p))
  if(parts.some(b=>b.right-b.left>21 || b.bottom-b.top>21))return null
  const centers=parts.map(b=>[(b.left+b.right)/2,(b.top+b.bottom)/2]).sort((a,b)=>a[0]-b[0])
  const [a,b]=centers, space=dist(a,b)
  if(space<45 || space>250 || Math.abs(a[1]-b[1])>space*.52)return null
  const vx=(b[0]-a[0])/space, vy=(b[1]-a[1])/space, r=space*.40
  const at=(eye,u,v)=>[eye[0]+u*vx-v*vy,eye[1]+u*vy+v*vx]
  const rings=centers.map(eye=>Array.from({length:49},(_,i)=>{
    const t=Math.PI*2*i/48
    return at(eye,r*Math.cos(t),r*.87*Math.sin(t))
  }))
  const bridge=curve(at(a,r,0),at(a,space*.5,-r*.45),at(b,-r,0))
  const arms=[ [at(a,-r,0),at(a,-r*1.43,-r*.74),at(a,-r*1.63,-r*.64)],
    [at(b,r,0),at(b,r*1.43,-r*.74),at(b,r*1.63,-r*.64)] ]
  return planned('glasses','眼镜','两枚镜框用拱形鼻梁相连，向后伸出折弯的镜腿，两点原线成为镜中的眼睛。',[...rings,bridge,...arms],
    [group('左右镜框',...rings),group('镜桥与镜腿',bridge,...arms)])
}
export function adaptiveComposition(original) {
  return glassesPlan(original) || saxophonePair(original) || jellyfishPlan(original)
}
