// Layouts that can use a freely bending original line as rigging, a tentacle,
// or a flying line. The two input strokes are never edited or returned as additions.
const W = 800, H = 560
const pen = p => ({c:'#423d4b', p})
const dist = (a,b) => Math.hypot(a[0]-b[0], a[1]-b[1])
const length = p => p.slice(1).reduce((sum,q,i) => sum + dist(q,p[i]),0)
const bounds = p => ({
  left:Math.min(...p.map(q=>q[0])), right:Math.max(...p.map(q=>q[0])),
  top:Math.min(...p.map(q=>q[1])), bottom:Math.max(...p.map(q=>q[1]))
})
const inside = ([x,y]) => x >= 5 && x <= W-5 && y >= 5 && y <= H-5
const group = (name,...paths) => ({name,paths})
function curve(a,b,c,steps=20) {
  return Array.from({length:steps+1},(_,i)=>{
    const t=i/steps, s=1-t
    return [s*s*a[0]+2*t*s*b[0]+t*t*c[0],s*s*a[1]+2*t*s*b[1]+t*t*c[1]]
  })
}
function planned(id,name,anatomy,lines,features) {
  if (!lines.every(p=>p.every(([x,y])=>x>=0 && x<=W && y>=0 && y<=H))) return null
  return {subject:{id,name,anatomy},strokes:lines.map(pen),features}
}

export function sailPlan(original) {
  for (const mastIndex of [0,1]) {
    const mast=original[mastIndex].p, sail=original[1-mastIndex].p
    const [top,foot]=[mast[0],mast.at(-1)].sort((a,b)=>a[1]-b[1])
    const h=foot[1]-top[1], b=bounds(sail)
    if (h<85 || Math.abs(foot[0]-top[0])>h*.24 || length(mast)>dist(top,foot)*1.12) continue
    const [tip,clew]=[sail[0],sail.at(-1)].sort((a,b)=>a[1]-b[1])
    const side = (b.left+b.right)/2 < top[0] ? -1 : 1
    const span = side===-1 ? top[0]-b.left : b.right-top[0]
    if (span < h*.5 || span > h*2 || b.right-b.left<h*.28 ||
        (side===-1?b.right>top[0]+8:b.left<top[0]-8) ||
        Math.abs(tip[1]-top[1])>h*.40 || b.bottom>foot[1]-6 ||
        b.top<top[1]-h*.36 || clew[1]-tip[1]<h*.33) continue
    // Require the open player-supplied sail to enclose visible area after
    // closing its endpoints. This avoids using a straight line as a flat sail.
    let area=0
    for (let i=0;i<sail.length;i++){
      const a=sail[i],z=sail[(i+1)%sail.length]; area+=a[0]*z[1]-z[0]*a[1]
    }
    if (Math.abs(area)/2 < span*h*.045) continue
    const oppositeSpace = side<0 ? W-foot[0]-20 : foot[0]-20
    const jibWidth=Math.min(h*.51,oppositeSpace-15)
    if(jibWidth<h*.22) continue
    const jibTop=[top[0]+(foot[0]-top[0])*.11,top[1]+h*.11]
    const jibOuter=[foot[0]-side*jibWidth,foot[1]-h*.16]
    const jibInner=[foot[0]+(top[0]-foot[0])*.13,foot[1]-h*.13]
    const jib=[jibTop,jibOuter,jibInner]
    const nearSide=side<0 ? b.left : b.right
    const bow=[nearSide+side*12,foot[1]]
    const stern=[jibOuter[0]-side*12,foot[1]]
    const beam=Math.abs(stern[0]-bow[0]), keel=Math.min(54,beam*.115)
    const hull=[[bow[0],bow[1]],[bow[0]-side*beam*.12,bow[1]+keel],[stern[0]+side*beam*.09,stern[1]+keel],stern,bow]
    const edge=[tip,clew], rig=[tip,top]
    const rigFoot=[clew,[foot[0]+(top[0]-foot[0])*.17,foot[1]-h*.17]]
    const res=planned('sailboat','帆船','一侧大三角帆、一侧小前帆、竖立的桅杆、两端上翘的船身。两条原线分别构成帆的边缘和桅杆。',[edge,rig,jib,rigFoot,hull],
      [group('三角帆',sail,edge),group('侧帆',jib),group('船身',hull)])
    if(res)return res
  }
  return null
}

function sampled(path, max=70) {
  return path.length<=max ? path : Array.from({length:max},(_,i)=>path[Math.round((path.length-1)*i/(max-1))])
}
function jellyfishPlan(original) {
  const paths=original.map(s=>s.p)
  const starts=paths.map(p=>p[0][1]<=p.at(-1)[1]?p[0]:p.at(-1)).sort((a,b)=>a[0]-b[0])
  const [a,b]=starts, gap=b[0]-a[0], mid=(a[0]+b[0])/2, y=(a[1]+b[1])/2
  if(gap<27 || gap>275 || Math.abs(a[1]-b[1])>Math.min(gap*.4,48))return null
  if(paths.some(p=>bounds(p).top<y-32 || bounds(p).bottom<y+50))return null
  const rx=Math.max(64,gap*.72), ry=rx*.73
  const left=[mid-rx,y+2], right=[mid+rx,y+2]
  const dome=Array.from({length:41},(_,i)=>{
    const angle=Math.PI*(1-i/40)
    return [mid+rx*Math.cos(angle),y+2-ry*Math.sin(angle)]
  })
  const edges=[left,a,[(a[0]+b[0])/2,y],b,right], scallop=[]
  for(let i=0;i<edges.length-1;i++){
    const p=edges[i],q=edges[i+1]
    const arc=curve(p,[(p[0]+q[0])/2,Math.max(p[1],q[1])+Math.min(20,(q[0]-p[0])*.5)],q)
    scallop.push(...arc.slice(i?1:0))
  }
  const feeler=curve([mid,y],[mid+rx*.45,y+ry*.52],[mid+rx*.12,y+ry*.79])
    .concat(curve([mid+rx*.12,y+ry*.79],[mid-rx*.18,y+ry*1.04],[mid+rx*.02,y+ry*1.29]).slice(1))
  const rib=curve([mid-rx*.56,y-ry*.66],[mid-rx*.68,y-ry*.6],[mid-rx*.76,y-ry*.4])
  return planned('jellyfish','水母','半圆钟罩，下缘呈扇贝波浪；两条原始笔画都从罩子边缘垂下，成为触手。',[dome,scallop,feeler,rib],
    [group('钟形伞盖',dome),group('波浪裙边',scallop),group('下垂的触手',...paths,feeler)])
}
function kitePlan(original) {
  const placements=[]
  const segments=original.map(s=>sampled(s.p))
  for(let n=0;n<2;n++) {
    const p=original[n].p
    const ends=[{at:p[0],next:p[Math.min(p.length-1,4)]},{at:p.at(-1),next:p[Math.max(0,p.length-5)]}]
    const options=[]
    for(const {at:fixedEnd,next} of ends) {
      const at=[Math.max(8, Math.min(W-8,fixedEnd[0])), Math.max(8, Math.min(H-8,fixedEnd[1]))]
      // The diamond's bottom tip meets the exact end of the flying line.
      for(const radius of [53,38,26]) for(let k=0;k<12;k++) {
        const t=k*Math.PI/6, ux=Math.sin(t), uy=-Math.cos(t)
        const from=(along,across=0)=>[at[0]+ux*along-uy*across,at[1]+uy*along+ux*across]
        const top=from(radius*2), left=from(radius*1.22,-radius*.7),right=from(radius*1.22,radius*.7)
        const diamond=[at,left,top,right,at], center=from(radius*1.08)
        if(!diamond.every(inside))continue
        let interference=0
        for(const points of segments)for(const q of points) {
          const dx=q[0]-at[0],dy=q[1]-at[1]
          const along=dx*ux+dy*uy, across=Math.abs(-dx*uy+dy*ux)
          if(along>4 && along<radius*2 && across<radius*.7*(1-Math.abs(along/radius-1)/1.1)+5)interference++
        }
        const vx=next[0]-at[0],vy=next[1]-at[1]
        const direction=(vx*ux+vy*uy)/(Math.hypot(vx,vy)||1)
        options.push({at,fixedEnd,top,left,right,center,radius,diamond,from,
          score:radius*.5 - interference*6 - direction*5 - uy*4})
      }
    }
    if(!options.length)return null
    placements.push(options)
  }
  let best=null
  for(const a of placements[0]) for(const b of placements[1]){
    const overlap=Math.max(0,(a.radius+b.radius)*1.2-dist(a.center,b.center))
    const score=a.score+b.score-overlap*2
    if(!best||score>best.score)best={a,b,score}
  }
  const lines=[],diamonds=[],braces=[]
  for(const k of [best.a,best.b]) {
    const spine=[k.at,k.top], cross=[k.left,k.right]
    diamonds.push(k.diamond);braces.push(spine,cross)
    lines.push(k.diamond,spine,cross)
    if(dist(k.fixedEnd,k.at)>0.5)lines.push([k.fixedEnd,k.at])
    const tip=k.at, along=k.radius*.14, span=k.radius*.21
    const bow=[tip,k.from(-along,span),k.from(along*.35,span),tip,k.from(-along,-span),k.from(along*.35,-span),tip]
    if(bow.every(inside))lines.push(bow)
  }
  return planned('kites','放风筝','两条原线各是牵住一只风筝的线，线端接菱形风筝，骨架交叉并有小蝴蝶结。',lines,
    [group('两只菱形风筝',...diamonds),group('交叉的竹骨',...braces)])
}
function glassesPlan(original) {
  const parts=original.map(s=>bounds(s.p))
  if(parts.some(b=>b.right-b.left>21 || b.bottom-b.top>21))return null
  const centers=parts.map(b=>[(b.left+b.right)/2,(b.top+b.bottom)/2]).sort((a,b)=>a[0]-b[0])
  const [a,b]=centers, space=dist(a,b)
  if(space<45 || space>250 || Math.abs(a[1]-b[1])>space*.52)return null
  const vx=(b[0]-a[0])/space, vy=(b[1]-a[1])/space, r=space*.40
  const at=(eye,u,v)=>[eye[0]+u*vx-v*vy,eye[1]+u*vy+v*vx]
  const rings=centers.map(eye=>Array.from({length:49},(_,i)=>{
    const t=Math.PI*2*i/48
    return at(eye,r*Math.cos(t),r*.87*Math.sin(t))
  }))
  const bridge=curve(at(a,r,0),at(a,space*.5,-r*.45),at(b,-r,0))
  const arms=[ [at(a,-r,0),at(a,-r*1.43,-r*.74),at(a,-r*1.63,-r*.64)],
    [at(b,r,0),at(b,r*1.43,-r*.74),at(b,r*1.63,-r*.64)] ]
  return planned('glasses','眼镜','两枚镜框用拱形鼻梁相连，向后伸出折弯的镜腿，两点原线成为镜中的眼睛。',[...rings,bridge,...arms],
    [group('左右镜框',...rings),group('镜桥与镜腿',bridge,...arms)])
}
export function adaptiveComposition(original) {
  return glassesPlan(original) || jellyfishPlan(original) || kitePlan(original)
}
