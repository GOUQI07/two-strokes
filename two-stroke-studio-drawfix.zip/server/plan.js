import {chooseComposition, chooseSingleAnchorScene} from './composition.js'
import {adaptiveComposition, sailPlan} from './adaptive.js'

export function planDrawing(original) {
  return sailPlan(original) || chooseComposition(original) || chooseSingleAnchorScene(original) || adaptiveComposition(original)
}

export function guideResult(plan, rescue=false) {
  return {
    title:'两笔成画', subject:plan.subject.name,
    source:rescue ? 'guide-fallback' : 'guide',
    reveal:rescue ? '本轮采用和原线匹配的参考画法。' : '参考画法', strokes:plan.strokes
  }
}

