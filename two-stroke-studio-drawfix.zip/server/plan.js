import {chooseComposition, chooseSingleAnchorScene} from './composition.js'
import {adaptiveComposition, sailPlan} from './adaptive.js'

export function planDrawing(original) {
  return sailPlan(original) || chooseComposition(original) || chooseSingleAnchorScene(original) || adaptiveComposition(original)
}

export function guideResult(plan) {
  return {
    title:'两笔成画', subject:plan.subject.name,
    source:'guide',
    reveal:'参考画法', strokes:plan.strokes
  }
}

