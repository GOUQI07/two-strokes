// Convert only the added ink into centerlines. All coordinates here are in the
// player's 800 × 560 space, after cropping and downsampling the model's edit.
const PEN = '#423d4b'
const STEP_X = [0, 1, 1, 1, 0, -1, -1, -1]
const STEP_Y = [-1, -1, 0, 1, 1, 1, 0, -1]
const DIAGONAL = Math.SQRT2

function unusable(message) {
  return Object.assign(new Error(message), { code: 'UNUSABLE_EDIT' })
}

function markOriginal(strokes, width, height) {
  const center = new Uint8Array(width * height)
  const samples = []
  for (const stroke of strokes) {
    const sample = []
    const path = stroke.p
    const stepsIn = (a, b) => Math.ceil(Math.max(Math.abs(a[0] - b[0]), Math.abs(a[1] - b[1])))
    const totalSteps = path.slice(1).reduce((total, point, i) => total + stepsIn(path[i], point), 0)
    // Dense or self-crossing drawings still get a bounded registration sample.
    const stride = Math.max(3, Math.ceil(totalSteps / 512))
    let stepIndex = 0
    const mark = (x, y) => {
      x = Math.max(0, Math.min(width - 1, Math.round(x)))
      y = Math.max(0, Math.min(height - 1, Math.round(y)))
      center[y * width + x] = 1
      if (stepIndex % stride === 0 || stepIndex === totalSteps) sample.push([x, y])
      stepIndex++
    }
    mark(...path[0])
    for (let i = 1; i < path.length; i++) {
      const [x, y] = path[i - 1]
      const dx = path[i][0] - x
      const dy = path[i][1] - y
      const steps = stepsIn(path[i - 1], path[i])
      for (let j = 1; j <= steps; j++) mark(x + dx * j / steps, y + dy * j / steps)
    }
    samples.push(sample)
  }
  return { center, samples }
}

// Two-pass chamfer distance is sufficient for a five-pixel protection halo.
function distanceTo(mask, width, height) {
  const distance = Float32Array.from(mask, value => value ? 0 : width + height)
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const k = y * width + x
      let d = distance[k]
      if (x) d = Math.min(d, distance[k - 1] + 1)
      if (y) {
        d = Math.min(d, distance[k - width] + 1)
        if (x) d = Math.min(d, distance[k - width - 1] + DIAGONAL)
        if (x + 1 < width) d = Math.min(d, distance[k - width + 1] + DIAGONAL)
      }
      distance[k] = d
    }
  }
  for (let y = height - 1; y >= 0; y--) {
    for (let x = width - 1; x >= 0; x--) {
      const k = y * width + x
      let d = distance[k]
      if (x + 1 < width) d = Math.min(d, distance[k + 1] + 1)
      if (y + 1 < height) {
        d = Math.min(d, distance[k + width] + 1)
        if (x) d = Math.min(d, distance[k + width - 1] + DIAGONAL)
        if (x + 1 < width) d = Math.min(d, distance[k + width + 1] + DIAGONAL)
      }
      distance[k] = d
    }
  }
  return distance
}

function readInk(pixels, width, height, channels) {
  const ink = new Uint8Array(width * height)
  const blue = new Uint8Array(ink.length)
  let blueCount = 0
  let inkCount = 0
  for (let i = 0; i < ink.length; i++) {
    const off = i * channels
    const red = pixels[off], green = pixels[off + 1], b = pixels[off + 2]
    const alpha = channels === 4 ? pixels[off + 3] / 255 : 1
    if (alpha > 0.5 && b - red > 55 && b - green > 25) {
      blue[i] = 1
      blueCount++
      continue
    }
    const luminance = red * 0.213 + green * 0.715 + b * 0.072
    const chroma = Math.max(red, green, b) - Math.min(red, green, b)
    if ((255 - luminance) * alpha > 78 && chroma <= 53) {
      ink[i] = 1
      inkCount++
    }
  }
  if (inkCount < 15 || inkCount > ink.length * 0.20) {
    throw unusable('这张补画的线稿为空或上色面积过大，请重新尝试。')
  }
  return { ink, blue, blueCount }
}

// Small registration correction when the edit returns the two blue guides
// together but displaced. Score both strokes independently so a long first
// stroke cannot conceal a moved or missing second stroke.
function guideOffset(guide, samples, width, height, confirmedGuide) {
  const distance = distanceTo(guide, width, height)
  function measure(dx, dy) {
    let sum = 0
    let worstCoverage = 1
    for (const path of samples) {
      let cost = 0
      let agree = 0
      for (const [x, y] of path) {
        const xx = x + dx, yy = y + dy
        const d = xx < 0 || yy < 0 || xx >= width || yy >= height
          ? 20 : distance[yy * width + xx]
        cost += Math.min(d, 16)
        if (d <= 6) agree++
      }
      sum += cost / path.length
      worstCoverage = Math.min(worstCoverage, agree / path.length)
    }
    return { dx, dy, score: sum / samples.length + Math.hypot(dx, dy) * 0.025, coverage: worstCoverage }
  }
  const zero = measure(0, 0)
  let best = zero
  if (best.score < 0.4 && best.coverage >= 0.95) return best
  for (let dy = -24; dy <= 24; dy += 4) {
    for (let dx = -24; dx <= 24; dx += 4) {
      const trial = measure(dx, dy)
      if (trial.score < best.score) best = trial
    }
  }
  const coarse = best
  for (let y = -3; y <= 3; y++) {
    for (let x = -3; x <= 3; x++) {
      const trial = measure(coarse.dx + x, coarse.dy + y)
      if (trial.score < best.score) best = trial
    }
  }
  if (confirmedGuide && best.coverage < 0.55) {
    throw unusable('生成图中的底稿偏移过大，无法与原来的两笔对齐。')
  }
  // Some edits recolor the guides black. Only register a monochrome output
  // if *both* complete strokes are present with very strong geometric support.
  if (!confirmedGuide && (best.coverage < 0.96 || best.score > 1.5 || zero.score - best.score < 1.8)) {
    return zero
  }
  return best
}

function thin(ink, width, height) {
  const active = []
  // The thinning operator uses one background pixel around every point.
  ink.fill(0, 0, width)
  ink.fill(0, (height - 1) * width)
  for (let y = 1; y < height - 1; y++) {
    ink[y * width] = ink[(y + 1) * width - 1] = 0
    for (let x = 1; x < width - 1; x++) {
      const k = y * width + x
      if (ink[k]) active.push(k)
    }
  }
  // Zhang–Suen's two deletion passes preserve connected paths and loops.
  let changed = true
  while (changed) {
    changed = false
    for (let pass = 0; pass < 2; pass++) {
      const removed = []
      for (const k of active) {
        if (!ink[k]) continue
        const n = ink[k - width], ne = ink[k - width + 1], e = ink[k + 1], se = ink[k + width + 1]
        const s = ink[k + width], sw = ink[k + width - 1], w = ink[k - 1], nw = ink[k - width - 1]
        const count = n + ne + e + se + s + sw + w + nw
        if (count < 2 || count > 6) continue
        const starts = (1-n)*ne + (1-ne)*e + (1-e)*se + (1-se)*s + (1-s)*sw + (1-sw)*w + (1-w)*nw + (1-nw)*n
        if (starts !== 1) continue
        const keep = pass === 0 ? n*e*s || e*s*w : n*e*w || n*s*w
        if (!keep) removed.push(k)
      }
      for (const k of removed) ink[k] = 0
      if (removed.length) changed = true
    }
  }
  return active
}

// Reduce pixel stairs while keeping corners (open or closed paths).
function simplify(path) {
  if (path.length < 3) return path
  const keep = new Uint8Array(path.length)
  keep[0] = keep[path.length - 1] = 1
  const ranges = [[0, path.length - 1]]
  while (ranges.length) {
    const [lo, hi] = ranges.pop()
    const [x, y] = path[lo]
    const dx = path[hi][0] - x, dy = path[hi][1] - y, length2 = dx * dx + dy * dy
    let worst = 0.9 ** 2, split = -1
    for (let i = lo + 1; i < hi; i++) {
      const px = path[i][0] - x, py = path[i][1] - y
      const t = length2 ? Math.max(0, Math.min(1, (px * dx + py * dy) / length2)) : 0
      const d2 = (px - t * dx) ** 2 + (py - t * dy) ** 2
      if (d2 > worst) { worst = d2; split = i }
    }
    if (split !== -1) {
      keep[split] = 1
      ranges.push([lo, split], [split, hi])
    }
  }
  return path.filter((_, i) => keep[i])
}

function followPaths(skeleton, active, width) {
  const edges = new Uint8Array(skeleton.length)
  const starts = []
  const points = []
  const indexStep = STEP_X.map((dx, i) => dx + STEP_Y[i] * width)
  for (const k of active) {
    if (!skeleton[k]) continue
    let count = 0
    for (let d = 0; d < 8; d++) {
      if (!skeleton[k + indexStep[d]]) continue
      // If a cardinal route exists, skip this diagonal triangle; otherwise
      // T-junctions acquire spurious one-pixel branches.
      if (d % 2 && (skeleton[k + STEP_X[d]] || skeleton[k + STEP_Y[d] * width])) continue
      edges[k] |= 1 << d
      count++
    }
    if (count === 1) starts.push(k)
    if (count >= 2) points.push(k)
  }
  const paths = []
  for (const start of [...starts, ...points]) {
    while (edges[start]) {
      const path = [[start % width, Math.floor(start / width)]]
      let k = start, last = -1
      while (edges[k]) {
        let best = -1, bestTurn = 9
        for (let d = 0; d < 8; d++) {
          if (!(edges[k] & (1 << d))) continue
          const turn = last < 0 ? 0 : Math.min(Math.abs(last - d), 8 - Math.abs(last - d))
          if (turn < bestTurn) { best = d; bestTurn = turn }
        }
        const next = k + indexStep[best]
        edges[k] &= ~(1 << best)
        edges[next] &= ~(1 << ((best + 4) % 8))
        k = next
        last = best
        path.push([k % width, Math.floor(k / width)])
      }
      if (path.length >= 3) paths.push(path)
    }
  }
  return paths
}

// Preserve the generated silhouette, variable line weight and filled details.
// Connected-component growth from accepted centerlines drops isolated noise.
// A pixel of paper may contain compression noise; use a conservative white
// cutoff, then preserve intermediate coverage on the anti-aliased edge.
function extractAlpha(pixels, width, height, channels, offset, protectedDistance, paths) {
  const count = width * height
  const available = new Uint8Array(count)
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const k = y * width + x
      if (protectedDistance[k] <= 3.25) continue
      const xx = x + offset.dx, yy = y + offset.dy
      if (xx < 0 || yy < 0 || xx >= width || yy >= height) continue
      const off = (yy * width + xx) * channels
      const r = pixels[off], g = pixels[off + 1], b = pixels[off + 2]
      if (Math.max(r, g, b) - Math.min(r, g, b) > 53 || (b - r > 18 && b - g > 6)) continue
      const darkness = (255 - (r * 0.213 + g * 0.715 + b * 0.072)) * (channels === 4 ? pixels[off + 3] / 255 : 1)
      if (darkness > 30) available[k] = Math.min(255, Math.round((darkness - 12) * 255 / 180))
    }
  }
  const selected = new Uint8Array(count)
  const queue = new Int32Array(count)
  const visited = new Uint8Array(count)
  const centerline = new Uint8Array(count)
  for (const path of paths) {
    for (const [x, y] of path) centerline[(y - offset.dy) * width + x - offset.dx] = 1
  }
  let accepted = 0
  for (let start = 0; start < count; start++) {
    if (!available[start] || visited[start]) continue
    visited[start] = 1
    let size = 1, minX = width, maxX = 0, minY = height, maxY = 0
    let xSum = 0, ySum = 0, strong = 0, hasSeed = false
    queue[0] = start
    for (let head = 0; head < size; head++) {
      const k = queue[head], x = k % width, y = Math.floor(k / width)
      minX = Math.min(minX, x); maxX = Math.max(maxX, x)
      minY = Math.min(minY, y); maxY = Math.max(maxY, y)
      xSum += x
      ySum += y
      if (available[k] >= 170) strong++
      if (centerline[k]) hasSeed = true
      for (let i = 0; i < 8; i++) {
        const xx = x + STEP_X[i], yy = y + STEP_Y[i], next = yy * width + xx
        if (xx >= 0 && yy >= 0 && xx < width && yy < height && available[next] && !visited[next]) {
          visited[next] = 1
          queue[size++] = next
        }
      }
    }
    if (!hasSeed) {
      // A compact facial detail centered between four pixels may vanish in
      // thinning. Keep its full alpha and provide a tiny animation seed.
      if (strong < 6 || size < 9 || maxX - minX > 30 || maxY - minY > 30) continue
      if (size < (maxX - minX + 1) * (maxY - minY + 1) * 0.40) continue
      const cx = Math.round(xSum / size), cy = Math.round(ySum / size)
      if (protectedDistance[cy * width + cx] <= 6) continue
      paths.push([[cx + offset.dx, cy + offset.dy], [Math.min(width - 1, cx + 1) + offset.dx, cy + offset.dy]])
    }
    for (let j = 0; j < size; j++) selected[queue[j]] = available[queue[j]]
    accepted += size
  }
  if (paths.length > 160) throw unusable('细碎笔画过多，请重新尝试。')
  if (accepted < 15 || accepted > count * 0.22) throw unusable('这张补画的线稿区域无效，请再试一次。')
  return selected
}

export function traceEdit({ pixels, width = 800, height = 560, channels = 4, original }) {
  if (pixels.length !== width * height * channels || ![3, 4].includes(channels)) {
    throw new TypeError('Invalid RGB image dimensions')
  }
  const { center, samples } = markOriginal(original, width, height)
  const protectedDistance = distanceTo(center, width, height)
  const { ink, blue, blueCount } = readInk(pixels, width, height, channels)
  const hasBlueGuide = blueCount >= 35
  const offset = guideOffset(hasBlueGuide ? blue : ink, samples, width, height, hasBlueGuide)
  const active = thin(ink, width, height)
  const coordinate = (x, y) => [x - offset.dx, y - offset.dy]
  let nearGuide = false
  for (const k of active) {
    if (!ink[k]) continue
    const [x, y] = coordinate(k % width, Math.floor(k / width))
    if (x < 0 || y < 0 || x >= width || y >= height || protectedDistance[y * width + x] <= 5) {
      ink[k] = 0
    } else if (protectedDistance[y * width + x] < 22) {
      nearGuide = true
    }
  }
  const paths = followPaths(ink, active, width)
  // If only distant independent artwork exists, do not attach it to the
  // player's strokes. This is a geometric sanity check, not a vision score.
  const length = paths.reduce((total, path) => total + path.length, 0)
  if (!nearGuide || length < 24 || paths.length > 160) {
    throw unusable('未提取到与底稿衔接的清晰笔画，请再试一次。')
  }
  // Reveal the long silhouette before the small facial features.
  paths.sort((left, right) => right.length - left.length)
  const inkAlpha = extractAlpha(pixels, width, height, channels, offset, protectedDistance, paths)
  const strokes = paths.map(path => ({ c: PEN, p: simplify(path).map(([x, y]) => coordinate(x, y)) }))
  return { strokes, inkAlpha }
}

export function traceAdditions(input) {
  return traceEdit(input).strokes
}

