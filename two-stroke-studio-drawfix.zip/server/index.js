import express from 'express'
import 'dotenv/config'
import path from 'node:path'
import {fileURLToPath} from 'node:url'
import {DEFAULT_IMAGE_MODEL} from './image-edit.js'
import {completeDrawing} from './complete.js'

const app = express()
app.disable('x-powered-by')
app.use(express.json({limit:'110kb'}))
const root = fileURLToPath(new URL('../', import.meta.url))
const model = process.env.OPENAI_IMAGE_MODEL || DEFAULT_IMAGE_MODEL
const requests = new Map()
const running = new Set()

app.get('/api/health', (_req, res) => res.json({
  ok:true, version:'silhouette-v6', aiConfigured:Boolean(process.env.OPENAI_API_KEY),
  accessCodeRequired:Boolean(process.env.GAME_ACCESS_CODE), model
}))

function validOriginal(strokes) {
  return Array.isArray(strokes) && strokes.length === 2 && strokes.every(s =>
    s && /^#[a-f\d]{6}$/i.test(s.c) && Array.isArray(s.p) &&
    s.p.length >= 1 && s.p.length <= 2200 &&
    s.p.every(p => Array.isArray(p) && p.length === 2 && p.every(Number.isFinite) &&
      p[0] >= 0 && p[0] <= 800 && p[1] >= 0 && p[1] <= 560))
}

app.post('/api/complete', async (req, res) => {
  if (process.env.GAME_ACCESS_CODE && req.get('x-game-access-code') !== process.env.GAME_ACCESS_CODE) {
    return res.status(403).json({error:'请输入画室访问码'})
  }
  const original = req.body?.strokes
  if (!validOriginal(original)) return res.status(400).json({error:'请在画板上完成两笔后再补画'})
  if (!process.env.OPENAI_API_KEY) return res.status(503).json({error:'请先在服务端配置 OPENAI_API_KEY'})
  const key = req.ip || 'unknown'
  const now = Date.now()
  for (const [ip, times] of requests) {
    if (times[times.length - 1] < now - 60000) requests.delete(ip)
  }
  const recent = (requests.get(key) || []).filter(t => t > now - 60000)
  if (recent.length >= 4) return res.status(429).json({error:'这一分钟的补画次数已用完，请稍后再试'})
  // A duplicate submission while the same drawing is in flight must not start a second image job.
  const signature = key + JSON.stringify(original)
  if (running.has(signature)) return res.status(409).json({error:'这两笔正在补画，请等待当前结果'})
  running.add(signature)
  requests.set(key, [...recent, now])
  const controller = new AbortController()
  const disconnect = () => { if (!res.writableEnded) controller.abort() }
  res.once('close', disconnect)
  try {
    const result = await completeDrawing(original,{model, apiKey:process.env.OPENAI_API_KEY, signal:controller.signal})
    if (!res.destroyed) res.json(result)
  } catch (error) {
    if (res.destroyed) return
    console.error('Image edit failed', error.code || error.name, error.status || '')
    res.status(error.status || 502).json({error:error.publicMessage || '这次补画未完成，原画已保留。'})
  } finally {
    running.delete(signature)
    res.off('close', disconnect)
  }
})

app.use(express.static(path.join(root, 'dist')))
app.get('*', (_req, res) => res.sendFile(path.join(root, 'dist/index.html')))
app.listen(Number(process.env.PORT || 3000), '0.0.0.0', () => console.log('Two Strokes · silhouette-v6'))
