// Local, pose-specific geometry check. The final player ink contributes to the
// signature just as it does on screen. No image is uploaded to assess the edit.
const clamp = (value, low, high) => Math.min(high, Math.max(low, value))
const round = value => Math.round(value * 100) / 100

function rasterPaths(paths, width, height) {
  const mask = new Uint8Array(width * height)
  const mark = (x, y) => {
    x = Math.round(x); y = Math.round(y)
    if (x >= 0 && y >= 0 && x < width && y < height) mask[y * width + x] = 1
  }
  for (const path of paths) {
    if (!path.length) continue
    mark(...path[0])
    for (let i = 1; i < path.length; i++) {
      const [x, y] = path[i-1]
      const dx = path[i][0] - x, dy = path[i][1] - y
      const steps = Math.ceil(Math.max(Math.abs(dx), Math.abs(dy)))
      for (let j = 1; j <= steps; j++) mark(x + dx*j/steps, y + dy*j/steps)
    }
  }
  return mask
}

function distanceField(mask, width, height) {
  // Chamfer distances in units of 1/3 pixel, with approximate nearest seed.
  const count = mask.length
  const distance = new Uint16Array(count).fill(65530)
  const nearest = new Int32Array(count).fill(-1)
  for (let i = 0; i < count; i++) {
    if (mask[i]) { distance[i] = 0; nearest[i] = i }
  }
  const take = (i, neighbor, cost) => {
    const candidate = distance[neighbor] + cost
    if (candidate < distance[i]) {
      distance[i] = candidate
      nearest[i] = nearest[neighbor]
    }
  }
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const i = y * width + x
      if (x) take(i,i-1,3)
      if (y) {
        take(i,i-width,3)
        if (x) take(i,i-width-1,4)
        if (x+1 < width) take(i,i-width+1,4)
      }
    }
  }
  for (let y = height - 1; y >= 0; y--) {
    for (let x = width - 1; x >= 0; x--) {
      const i = y * width + x
      if (x+1 < width) take(i,i+1,3)
      if (y+1 < height) {
        take(i,i+width,3)
        if (x) take(i,i+width-1,4)
        if (x+1 < width) take(i,i+width+1,4)
      }
    }
  }
  return {distance, nearest}
}

// Compare primary directions at the nearest line rather than accepting every
// crossing. Corners, round dots and junctions carry no directional penalty.
function directions(mask, width, height, radius) {
  const cache = new Map()
  return function at(index) {
    if (cache.has(index)) return cache.get(index)
    const cx = index % width, cy = Math.floor(index / width)
    let n = 0, sx = 0, sy = 0, xx = 0, yy = 0, xy = 0
    for (let y = Math.max(0,cy-radius); y <= Math.min(height-1,cy+radius); y++) {
      for (let x = Math.max(0,cx-radius); x <= Math.min(width-1,cx+radius); x++) {
        const dx = x - cx, dy = y - cy
        if (!mask[y*width+x] || dx*dx + dy*dy > radius*radius) continue
        n++; sx+=dx; sy+=dy; xx+=dx*dx; yy+=dy*dy; xy+=dx*dy
      }
    }
    let direction = null
    if (n > 2) {
      xx -= sx*sx/n; yy -= sy*sy/n; xy -= sx*sy/n
      const spread = Math.hypot(xx - yy, 2*xy)
      if (spread > (xx+yy)*0.48) direction = [(xx-yy)/spread, 2*xy/spread]
    }
    cache.set(index, direction)
    return direction
  }
}

function pathSamples(path, spacing) {
  if (path.length < 2) return path.map(([x,y]) => ({x,y}))
  const result = []
  let remaining = 0
  for (let i = 1; i < path.length; i++) {
    const [x,y] = path[i-1], dx = path[i][0]-x, dy = path[i][1]-y
    const length = Math.hypot(dx,dy)
    if (!length) continue
    const ux = dx/length, uy = dy/length
    while (remaining <= length) {
      result.push({x:x+ux*remaining,y:y+uy*remaining,cos2:ux*ux-uy*uy,sin2:2*ux*uy})
      remaining += spacing
    }
    remaining -= length
  }
  const [x,y] = path.at(-1)
  if (!result.length || Math.hypot(result.at(-1).x-x,result.at(-1).y-y) > spacing/2) result.push({x,y})
  return result
}

function spanOf(paths) {
  let left = Infinity, top = Infinity, right = -Infinity, bottom = -Infinity
  for (const p of paths) for (const [x,y] of p) {
    left=Math.min(left,x); right=Math.max(right,x); top=Math.min(top,y); bottom=Math.max(bottom,y)
  }
  return Math.max(0,right-left,bottom-top)
}

function pathMatch(sampled, dx, dy, tolerance, field, direction, width, height) {
  let matching = 0
  for (const s of sampled) {
    const x = Math.round(s.x+dx), y = Math.round(s.y+dy)
    if (x < 0 || y < 0 || x >= width || y >= height) continue
    const i = y*width+x
    if (field.distance[i] > 3*tolerance) continue
    if (s.cos2 !== undefined && sampled.length >= 5) {
      const axis = direction(field.nearest[i])
      if (axis && s.cos2*axis[0] + s.sin2*axis[1] < -0.24) continue
    }
    matching++
  }
  return matching/Math.max(1,sampled.length)
}

export function evaluateFeatures(original, inkAlpha, width, height, features, expectedStrokes = []) {
  const fail = (reason, details=[]) => ({passed:false,reason,details})
  if (!features?.length || inkAlpha?.length !== width*height) return fail('empty')
  const originalPaths = original.map(s=>s.p)
  const scaffold = expectedStrokes.map(s=>s.p)
  const parts = features.map(f => ({name:f.name, paths:f.paths.filter(p=>p.length)}))
  if (parts.length < 2 || parts.some(f=>!f.paths.length)) return fail('features')
  const finalMask = rasterPaths(originalPaths,width,height)
  let newPixels = 0, broadPixels = 0
  for (let i = 0; i < inkAlpha.length; i++) {
    if (inkAlpha[i] < 80) continue
    newPixels++
    finalMask[i] = 1
    // Uniform filled regions should occupy little of a simple line drawing.
    const x = i%width, y = Math.floor(i/width), k = 6
    if (x < k || y < k || x+k >= width || y+k >= height) continue
    if (inkAlpha[i-k]>80 && inkAlpha[i+k]>80 && inkAlpha[i-k*width]>80 && inkAlpha[i+k*width]>80 &&
        inkAlpha[i-4*width-4]>80 && inkAlpha[i+4*width+4]>80 &&
        inkAlpha[i-4*width+4]>80 && inkAlpha[i+4*width-4]>80) broadPixels++
  }
  if (newPixels < 12) return fail('empty')
  if (newPixels > inkAlpha.length*.21 || broadPixels/newPixels > .34) return fail('density')
  const scale = spanOf([...parts.flatMap(f=>f.paths), ...scaffold])
  const tolerance = clamp(scale*.025,3,13)
  const spacing = clamp(scale/92,2.5,5)
  const field = distanceField(finalMask,width,height)
  const direction = directions(finalMask,width,height,Math.round(clamp(tolerance*.87,4,9)))
  const details = []
  for (const part of parts) {
    const sampled = part.paths.map(p=>pathSamples(p,spacing))
    // One translation per signature group is allowed. Paired components such
    // as the ears of a rabbit must remain in the same relative arrangement.
    const shift = Math.round(tolerance*.78)
    let best = {score:0,weakest:0}
    for (const dy of [0,-shift,shift]) for (const dx of [0,-shift,shift]) {
      const matches=sampled.map(p=>pathMatch(p,dx,dy,tolerance,field,direction,width,height))
      const weakest = Math.min(...matches)
      const mean = matches.reduce((a,b)=>a+b,0)/matches.length
      const score = .7*mean + .3*weakest
      if (score > best.score) best = {score,weakest}
    }
    details.push({name:part.name, score:round(best.score), weakest:round(best.weakest)})
  }
  if (details.some(d => d.score < .65 || d.weakest < .47)) return fail('features',details)
  if (scaffold.length) {
    // Broad, bidirectional silhouette check, in addition to the local named
    // parts. A matching trunk/ear next to a large stray drawing fails here.
    const broad = clamp(scale*.076,9,30)
    const expected = rasterPaths([...scaffold,...originalPaths],width,height)
    const ref = distanceField(expected,width,height).distance
    let nearbyNew = 0
    for (let i = 0; i < inkAlpha.length; i++) {
      if (inkAlpha[i] >= 80 && ref[i] <= 3*broad) nearbyNew++
    }
    let total = 0, matched = 0
    for (const p of scaffold) {
      const samples = pathSamples(p,spacing)
      total += samples.length
      matched += samples.length*pathMatch(samples,0,0,broad,field,direction,width,height)
    }
    const coverage = matched/Math.max(total,1), precision = nearbyNew/newPixels
    if (coverage < .59 || precision < .70) return {...fail('outline',details), coverage:round(coverage), precision:round(precision)}
  }
  return {passed:true,reason:'ok',details}
}
