import test from 'node:test'
import assert from 'node:assert/strict'
import { evaluateFeatures } from '../server/recognition.js'

const W=220,H=150
const spiral=Array.from({length:65},(_,i)=>{
  const t=i/64, a=t*Math.PI*3.8, r=3+t*24
  return [85+r*Math.cos(a),83+r*Math.sin(a)]
})
const feeler1=[[151,84],[153,67],[159,53]], feeler2=[[155,85],[167,70],[177,66]]
const head=[[130,103],[146,82],[157,82],[168,87],[173,100],[169,109],[154,116]]
const belly=[[154,116],[89,118],[39,115],[32,110],[57,103]]
const shell=Array.from({length:48},(_,i)=>{
  const a=(2*Math.PI*i)/47
  return [85+35*Math.cos(a),81+33*Math.sin(a)]
})
const features=[{name:'spiral',paths:[spiral]},{name:'feelers',paths:[feeler1,feeler2]}]
const original=[{p:belly,c:'#d97891'},{p:shell,c:'#423d4b'}]
const intended=[head,spiral,feeler1,feeler2].map(p=>({p}))
function bitmap(paths, width=2.5) {
  const alpha=new Uint8Array(W*H)
  for (const points of paths) for(let i=1;i<points.length;i++){
    const [x0,y0]=points[i-1], [x1,y1]=points[i], length=Math.max(1,Math.ceil(Math.hypot(x1-x0,y1-y0)))
    for(let j=0;j<=length;j++){
      const x=x0+(x1-x0)*j/length, y=y0+(y1-y0)*j/length
      for(let dy=-Math.ceil(width);dy<=Math.ceil(width);dy++) for(let dx=-Math.ceil(width);dx<=Math.ceil(width);dx++){
        const xx=Math.round(x)+dx, yy=Math.round(y)+dy
        if (xx>=0 && yy>=0 && xx<W && yy<H && Math.hypot(xx-x,yy-y)<=width) alpha[yy*W+xx]=255
      }
    }
  }
  return alpha
}
const check = a => evaluateFeatures(original,a,W,H,features,intended)

test('distinctive parts pass together, including natural small changes and an original feature',()=>{
  const shifted=intended.map(({p})=>p.map(([x,y])=>[x+3+Math.sin(y/12),y-2]))
  const alpha=bitmap(shifted)
  assert.equal(check(alpha).passed,true,JSON.stringify(check(alpha)))
  const aWithoutShell=bitmap([head,feeler1,feeler2])
  const ownSpiral=[{p:spiral,c:'#123456'},original[0]]
  const before=JSON.stringify(ownSpiral)
  assert.equal(evaluateFeatures(ownSpiral,aWithoutShell,W,H,features,intended).passed,true)
  assert.equal(JSON.stringify(ownSpiral),before)
})

test('a face on the body, one antenna, or a missing spiral cannot pass for a snail',()=>{
  const smile=[[80,84],[86,90],[92,91],[100,87]]
  const eye=[[86,72],[89,72]]
  for (const paths of [[eye,smile,head],[head,spiral,feeler1],[head,feeler1,feeler2]]) {
    const result=check(bitmap(paths))
    assert.equal(result.passed,false,JSON.stringify(result))
    assert.equal(result.reason,'features')
  }
})

test('a filled area overlapping every landmark is rejected',()=>{
  const alpha=new Uint8Array(W*H)
  for(let y=50;y<118;y++) alpha.fill(255,y*W+60,y*W+180)
  assert.equal(check(alpha).reason,'density')
})

test('a mostly unrelated second drawing is rejected even when the signatures exist',()=>{
  const stripes=Array.from({length:6},(_,i)=>[[0,4+7*i],[216,4+7*i]])
  const result=check(bitmap([...intended.map(s=>s.p),...stripes],1.2))
  assert.equal(result.passed,false)
  assert.equal(result.reason,'outline')
})
