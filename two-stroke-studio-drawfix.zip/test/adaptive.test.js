import assert from 'node:assert/strict'
import test from 'node:test'
import {adaptiveComposition} from '../server/adaptive.js'
import {planDrawing} from '../server/plan.js'

const strokes = paths => paths.map((p,i)=>({c:i?'#006077':'#773355',p}))
// Approximate the two open curves in the screenshot in 800 × 560 canvas units.
const hooks = strokes([
  [[251,166],[229,171],[198,190],[163,227],[149,264],[141,303],[141,333],[157,351],[192,364],[234,364],[262,355],[290,336],[306,310]],
  [[540,77],[540,145],[540,219],[539,278],[533,312],[522,339],[508,352],[482,359],[453,353],[439,345],[435,334],[440,317]]
])

test('unequal neighboring hooks use both long original contours as saxophone walls',()=>{
  const snapshot=JSON.stringify(hooks)
  for (const pair of [hooks,hooks.toReversed().map(s=>({...s,p:s.p.toReversed()}))]) {
    const plan=planDrawing(pair)
    assert.equal(plan?.subject.id,'sax-duet')
    assert.deepEqual(plan.features[0].paths,pair.map(s=>s.p))
    assert.equal(plan.features[1].paths.length,2)
    assert.ok(plan.strokes.every(line=>line.p.every(([x,y])=>x>=0&&x<=800&&y>=0&&y<=560)))
    for (const input of pair) assert.ok(!plan.strokes.some(line=>line.p===input.p))
  }
  assert.equal(JSON.stringify(hooks),snapshot)
})

test('dots and hanging tendrils have distinct supported reference subjects',()=>{
  assert.equal(adaptiveComposition(strokes([[[210,210]],[[340,215]]])).subject.id,'glasses')
  assert.equal(adaptiveComposition(strokes([[[290,215],[285,250],[315,300]],[[425,222],[439,257],[420,300]]])).subject.id,'jellyfish')
})

test('unsupported gestures decline without attaching objects to endpoints',()=>{
  const fixtures = [
    [[[0,0]],[[800,560]]],
    [[[100,280],[160,330],[241,310]],[[570,90],[500,50],[495,110]]],
    [[[70,80],[750,90]],[[50,140],[510,181]]]
  ]
  for(const fixture of fixtures) assert.equal(adaptiveComposition(strokes(fixture)),null)
})
