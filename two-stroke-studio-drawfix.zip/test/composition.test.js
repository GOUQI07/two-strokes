import assert from 'node:assert/strict'
import test from 'node:test'
import {chooseComposition, chooseSingleAnchorScene} from '../server/composition.js'
import {subjects} from '../server/subjects.js'

const catalog = [{
  id:'fixture', name:'茶壶', anatomy:'壶嘴和壶柄',
  strokes:[
    {id:'lid', anchor:true, feature:'壶盖', p:[[75,85],[100,73],[115,50],[125,73],[155,80]]},
    {id:'body', anchor:true, p:[[165,90],[180,110],[184,140],[175,160],[145,168]]},
    {id:'knob', p:[[115,50],[120,43],[126,50]]},
    {id:'base', p:[[145,168],[125,170],[70,167]]},
    {id:'spout', feature:'壶嘴', p:[[70,167],[48,140],[33,126],[29,107],[54,118],[75,125]]},
    {id:'handle', feature:'壶柄', p:[[169,94],[201,91],[215,105],[211,127],[184,140]]}
  ]
}]
const source=catalog[0].strokes
const make=(p,color='#423d4b')=>({c:color,p})
const transform=([x,y])=>[2*x+70,2*y+54]
const almost=(a,b,eps=1)=>Math.hypot(a[0]-b[0],a[1]-b[1]) <= eps

test('uses both exact source contours as locked layers and supplies remaining signature groups',()=>{
  const original=[make(source[0].p.map(transform),'#ac69bb'),make(source[1].p.map(transform).reverse())]
  const snapshot=JSON.stringify(original)
  const result=chooseComposition(original,catalog)
  assert.equal(result?.subject.id,'fixture')
  assert.equal(JSON.stringify(original),snapshot)
  assert.ok(result.fitScore>.99)
  assert.deepEqual(result.anchors.map(a=>a.id),['lid','body'])
  assert.equal(result.strokes.length,4)
  const lid=result.features.find(f=>f.name==='壶盖')
  assert.deepEqual(lid.paths,[original[0].p])
  assert.equal(lid.addedPaths.length,0)
  assert(result.features.find(f=>f.name==='壶柄').addedPaths.length)
  assert(almost(result.strokes[0].p[0],transform([115,50])))
})

test('supports swapped order, reversed paths, mirror, small joint offsets and in-bounds additions',()=>{
  const mirror=([x,y])=>[690-2.25*x,50+2.25*y]
  const a=source[1].p.map(mirror).reverse(), b=source[0].p.map(mirror)
  a[0]=[a[0][0]-5,a[0][1]+4]
  const result=chooseComposition([make(a),make(b)],catalog)
  assert(result)
  assert.deepEqual(result.anchors.map(anchor=>anchor.id),['body','lid'])
  assert(almost(result.strokes[1].p[0],a[0]))
  assert(result.strokes.every(s=>s.p.every(([x,y])=>x>=0&&x<800&&y>=0&&y<560)))
})

test('partial overlap keeps uncovered source contour and reconnects to the actual stroke endpoint',()=>{
  const p=source[1].p
  const seg=p.slice(1).map((b,i)=>Math.hypot(b[0]-p[i][0],b[1]-p[i][1]))
  let left=.65*seg.reduce((s,v)=>s+v,0)
  const partial=[p[0]]
  for(let i=0;i<seg.length;i++){
    if(left>=seg[i]) { partial.push(p[i+1]); left-=seg[i]; continue }
    const t=left/seg[i]
    partial.push([p[i][0]+t*(p[i+1][0]-p[i][0]),p[i][1]+t*(p[i+1][1]-p[i][1])])
    break
  }
  const original=[make(source[0].p.map(transform)),make(partial.map(transform))]
  const result=chooseComposition(original,catalog)
  assert(result)
  assert.equal(result.strokes.length,5)
  assert(almost(result.strokes[0].p[0],original[1].p.at(-1)))
})

test('declines taps, pathological scribbles, and matches that would crop the subject',()=>{
  const first=make(source[0].p.map(transform))
  assert.equal(chooseComposition([first,make([[400,240]])],catalog),null)
  assert.equal(chooseComposition([first,make([[10,10],[700,500],[10,10],[700,500],[10,10]])],catalog),null)
  const shift=([x,y])=>[x-65,200+y]
  assert.equal(chooseComposition([make(source[0].p.map(shift)),make(source[1].p.map(shift))],catalog),null)
})

test('authored subjects are identifiable with unmodified paired anchor paths', () => {
  for(const subject of subjects){
    const original=subject.strokes.filter(s=>s.anchor).slice(0,2)
      .map(s=>make(s.p.map(([x,y])=>[120+x*1.2,100+y*1.2])))
    const fit=chooseComposition(original)
    assert.equal(fit?.subject.id,subject.id)
    assert.ok(fit.fitScore>.98)
  }
})

test('a freeform upward steam line can integrate with a pot outline in either stroke order',()=>{
  const pot=subjects.find(s=>s.id==='teapot')
  const outline=pot.strokes.find(s=>s.id==='body-right').p
  const steam=[[72,105],[70,97],[79,84],[67,71],[63,60]]
  const original=[make(steam.map(transform).reverse()),make(outline.map(transform))]
  const copy=JSON.stringify(original)
  const fit=chooseSingleAnchorScene(original,[pot])
  assert.equal(fit?.subject.id,'teapot')
  assert.deepEqual(fit.anchors.map(a=>a.originalIndex),[1,0])
  assert.equal(fit.anchors[1].id,'壶嘴冒出的蒸汽')
  assert.equal(JSON.stringify(original),copy)
  assert.equal(fit.features.at(-1).paths[0],original[0].p)
})

test('an authored sailboat accepts a genuine supporting wave, not a disconnected scribble',()=>{
  const boat=subjects.find(s=>s.id==='sailboat')
  const mast=make(boat.strokes.find(s=>s.id==='mast').p.map(transform))
  const wave=make([[85,248],[132,246],[190,245],[230,249],[269,245],[326,250]].map(transform))
  const fit=chooseSingleAnchorScene([mast,wave],[boat])
  assert.equal(fit?.anchors[1].id,'托住船底的海浪')
  assert.equal(fit.features.at(-1).addedPaths.length,0)
  const unrelated=make([[75,80],[78,103],[82,78],[73,101],[77,79],[73,98]].map(transform))
  assert.equal(chooseSingleAnchorScene([mast,unrelated],[boat]),null)
})
