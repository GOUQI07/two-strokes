import assert from 'node:assert/strict'
import test from 'node:test'
import { traceEdit } from '../server/trace.js'

const width = 190, height = 145
const original = [
  { c: '#dd6688', p: [[30, 59], [37, 39], [58, 28]] },
  { c: '#5b98bc', p: [[119, 37], [140, 40], [148, 61]] }
]

function bitmap() { return new Uint8Array(width * height * 3).fill(255) }
function disk(pixels, x, y, radius, rgb) {
  for (let j = Math.max(0, Math.floor(y - radius - 1)); j < Math.min(height, y + radius + 1); j++) {
    for (let i = Math.max(0, Math.floor(x - radius - 1)); i < Math.min(width, x + radius + 1); i++) {
      const a = Math.min(1, Math.max(0, radius + 0.5 - Math.hypot(x - i, y - j)))
      for (let c = 0; c < 3; c++) {
        const k = (j * width + i) * 3 + c
        pixels[k] = Math.round(a * rgb[c] + (1 - a) * pixels[k])
      }
    }
  }
}
function draw(pixels, path, radius, rgb, offset = [0, 0]) {
  for (let i = 1; i < path.length; i++) {
    const [sx, sy] = path[i-1], [ex, ey] = path[i]
    const n = Math.ceil(Math.hypot(sx-ex, sy-ey))
    for (let j = 0; j <= n; j++) disk(pixels, sx + (ex-sx)*j/n + offset[0], sy + (ey-sy)*j/n + offset[1], radius, rgb)
  }
}
const blue = [22, 131, 232]
const ink = [25, 25, 25]

function example(offset, guide = blue) {
  const pixels = bitmap()
  draw(pixels, [[58,28],[85,15],[119,37]], 2.5, ink, offset)
  draw(pixels, [[30,59],[37,91],[70,109],[117,100],[148,61]], 3, ink, offset)
  disk(pixels, 77+offset[0], 54+offset[1], 6, ink)
  disk(pixels, 96+offset[0], 54+offset[1], 6, ink)
  disk(pixels, 171+offset[0], 112+offset[1], .5, ink) // isolated noise
  for (const s of original) draw(pixels, s.p, 2.5, guide, offset)
  return pixels
}
function trace(pixels) { return traceEdit({ pixels, width, height, channels:3, original }) }

test('linework integrates with unchanged originals; filled eyes retain area and noise is removed', () => {
  const input = JSON.stringify(original)
  const { strokes, inkAlpha } = trace(example([0,0]))
  assert.equal(JSON.stringify(original), input)
  assert.equal(inkAlpha.length, width * height)
  assert.ok(strokes.length >= 4 && strokes.length < 14, String(strokes.length))
  assert.ok(inkAlpha[109*width+70] > 200)
  assert.ok(inkAlpha[54*width+77] > 200 && inkAlpha[54*width+81] > 200)
  for (const s of original) for (const [x,y] of s.p) assert.equal(inkAlpha[y*width+x], 0)
  assert.equal(inkAlpha[112*width+171], 0)
  for (const s of strokes) for (const [x,y] of s.p) assert.ok(x>=0 && x<width && y>=0 && y<height)
})

test('round details centered between four pixels survive skeleton collapse', () => {
  const pixels = example([0,0])
  disk(pixels, 112.5, 63.5, 5, ink)
  const { inkAlpha } = trace(pixels)
  assert.equal(inkAlpha[64*width+113], 255)
})

test('both blue guides with small translation register the ink back onto the original canvas', () => {
  const { inkAlpha } = trace(example([13,-9]))
  assert.ok(inkAlpha[54*width+77] > 200)
  assert.ok(inkAlpha[109*width+70] > 0)
  assert.equal(inkAlpha[(54-9)*width+77+13], 0)
})

test('black guide redraw does not enter additions', () => {
  const { inkAlpha } = trace(example([0,0], ink))
  for (const s of original) for (const [x,y] of s.p) assert.equal(inkAlpha[y*width+x], 0)
  assert.ok(inkAlpha[54*width+77] > 200)
})

test('if both original outlines return in black at a small shared offset they also register', () => {
  const { inkAlpha } = trace(example([10,7], ink))
  assert.ok(inkAlpha[54*width+77] > 200)
  assert.equal(inkAlpha[54*width+77+13], 0)
  for (const s of original) for (const [x,y] of s.p) assert.equal(inkAlpha[y*width+x], 0)
})

test('empty image, unchanged guide, flooded canvas and unrelated detached output never become fake additions', () => {
  const guideOnly = bitmap()
  for (const s of original) draw(guideOnly, s.p, 2.5, blue)
  const distant = guideOnly.slice()
  draw(distant, [[22,120],[30,133],[52,133],[57,119]],2.5,ink)
  for (const invalid of [bitmap(), guideOnly, bitmap().fill(0), distant]) {
    assert.throws(() => trace(invalid), { code:'UNUSABLE_EDIT' })
  }
})

test('gross guide drift is refused', () => {
  const pixels = bitmap()
  for (const s of original) draw(pixels, s.p, 2.5, blue, [0,55])
  draw(pixels, [[58,83],[90,70],[119,92]],3,ink)
  assert.throws(() => trace(pixels), {code:'UNUSABLE_EDIT'})
})
