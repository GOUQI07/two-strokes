import test from 'node:test'
import assert from 'node:assert/strict'
import sharp from 'sharp'
import {createDoodleEdit} from '../server/image-edit.js'
import {completeDrawing} from '../server/complete.js'
import {planDrawing} from '../server/plan.js'

const original = [
  {c:'#d97891', p:[[240,225],[250,260],[260,300]]},
  {c:'#6298be', p:[[400,225],[390,260],[380,300]]}
]
const unchanged = input => input
function mockedModel(render, count) {
  return (strokes, options) => createDoodleEdit(strokes, {
    ...options,
    apiKey:'local-test',
    fetchImpl:async (_url, {body}) => {
      count.calls++
      assert.equal(body.get('n'), '1')
      const input = Buffer.from(await body.get('image').arrayBuffer())
      const png = await render(input)
      return Response.json({data:[{b64_json:png.toString('base64')}]})
    }
  })
}

// Both completions join the exact same two sides. One adds pointed tips,
// the other a brim and a handle. The server must preserve the actual choice.
function addInk(path) {
  return async input => {
    const overlay = Buffer.from(`<svg xmlns="http://www.w3.org/2000/svg" width="1536" height="1024">
      <svg x="48" y="8" width="1440" height="1008" viewBox="0 0 800 560">
        <path d="${path}" fill="none" stroke="black" stroke-linejoin="round" stroke-width="5"/>
      </svg></svg>`)
    return sharp(input).composite([{input:overlay}]).png().toBuffer()
  }
}
test('different actual edits on the same originals produce different replays, one request each', async () => {
  const snapshot = structuredClone(original)
  const crown = 'M240 225 L275 245 L320 190 L365 245 L400 225 M260 300 H380'
  const cup = 'M240 225 Q320 204 400 225 M260 300 Q320 316 380 300 M399 234 C460 215 451 289 384 286'
  const results = []
  for (const path of [crown, cup]) {
    const count = {calls:0}
    const result = await completeDrawing(original, {edit:mockedModel(addInk(path), count)})
    assert.equal(result.source, 'ai-edit')
    assert.equal(result.subject, '')
    assert.match(result.ink.map, /^data:image\/png;/)
    assert.equal(count.calls, 1)
    results.push(result)
  }
  assert.notEqual(results[0].ink.map, results[1].ink.map)
  assert.notDeepEqual(results[0].strokes, results[1].strokes)
  assert.deepEqual(original, snapshot)
})
test('unchanged or unusable image returns a clear error without substituting a reference or retrying', async () => {
  const snapshot = structuredClone(original)
  const count = {calls:0}
  await assert.rejects(completeDrawing(original, {edit:mockedModel(unchanged, count)}),
    error => error.status === 422 && error.publicMessage.includes('你的两笔已保留'))
  assert.equal(count.calls, 1)
  assert.deepEqual(original, snapshot)
})
test('an upstream service error is preserved', async () => {
  const error = Object.assign(new Error('No quota'), {status:503})
  await assert.rejects(completeDrawing(original, {edit:async () => {throw error}}), e => e === error)
})
test('two familiar ways to use long rigging and two short points without altering them', ()=>{
  const pair=p=>p.map(path=>({c:'#142834',p:path}))
  const sails=pair([[[331,144],[241,225],[194,289],[194,301],[209,319],[248,328],[354,324],[414,315]],[[585,160],[580,240],[570,317],[557,397]]])
  assert.equal(planDrawing(sails).subject.id,'sailboat')
  const dots=planDrawing(pair([[[210,210]],[[340,215]]]))
  assert.equal(dots.subject.id,'glasses')
  const corners=planDrawing(pair([[[0,0]],[[800,560]]]))
  assert.equal(corners, null)
})
