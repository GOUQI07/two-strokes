import test from 'node:test'
import assert from 'node:assert/strict'
import {createDoodleEdit} from '../server/image-edit.js'
import {completeDrawing} from '../server/complete.js'
import {planDrawing} from '../server/plan.js'
import {subjects} from '../server/subjects.js'
import sharp from 'sharp'

const original = subjects.find(s=>s.id==='elephant').strokes.filter(s=>['back','belly-leg'].includes(s.id))
  .map(s=>({c:'#d97891',p:s.p.map(([x,y])=>[x+120,y+120])}))
function mockEdit(render, count) {
  return (strokes,options)=>createDoodleEdit(strokes,{...options,apiKey:'local-test',fetchImpl:async (_url,{body})=>{
    count.calls++
    assert.equal(body.get('n'),'1')
    assert.match(body.get('prompt'),/小象/)
    const input=Buffer.from(await body.get('image').arrayBuffer())
    const png=await render(input)
    return Response.json({data:[{b64_json:png.toString('base64')}]})
  }})
}
test('a recognizable masked edit is animated without another model call', async ()=>{
  const count={calls:0}, snapshot=JSON.stringify(original)
  // Emulate an edit that inks only the pink guidelines, preserving the blue user lines.
  const result=await completeDrawing(original,{edit:mockEdit(async input=>{
    const {data,info}=await sharp(input).removeAlpha().raw().toBuffer({resolveWithObject:true})
    for(let i=0;i<data.length;i+=3) {
      if(data[i]>data[i+1]+10 && data[i+2]>data[i+1]+8){
        const gray=Math.max(0,255-(255-data[i+1])*3.3)
        data[i]=data[i+1]=data[i+2]=gray
      }
    }
    return sharp(data,{raw:info}).png().toBuffer()
  },count)})
  assert.equal(result.source,'ai-edit')
  assert.equal(result.subject,'小象')
  assert.match(result.ink.map,/^data:image\/png;/)
  assert.equal(count.calls,1)
  assert.equal(JSON.stringify(original),snapshot)
})
test('missing distinct parts return a clearly labeled guide, with the original two strokes locked', async ()=>{
  const count={calls:0}
  const result=await completeDrawing(original,{edit:mockEdit(img=>img,count)})
  assert.equal(count.calls,1)
  assert.equal(result.source,'guide-fallback')
  assert.match(result.reveal,/参考画法/)
  assert.deepEqual(result.strokes,planDrawing(original).strokes)
})
test('an unavailable paid model surfaces its error separately from geometric fallback', async ()=>{
  const error=Object.assign(new Error('No quota'),{status:503})
  await assert.rejects(completeDrawing(original,{edit:async()=>{throw error}}),e=>e===error)
})
test('two familiar ways to use long rigging and two short points without altering them', ()=>{
  const pair=p=>p.map(path=>({c:'#142834',p:path}))
  const sails=pair([[[331,144],[241,225],[194,289],[194,301],[209,319],[248,328],[354,324],[414,315]],[[585,160],[580,240],[570,317],[557,397]]])
  assert.equal(planDrawing(sails).subject.id,'sailboat')
  const dots=planDrawing(pair([[[210,210]],[[340,215]]]))
  assert.equal(dots.subject.id,'glasses')
  const corners=planDrawing(pair([[[0,0]],[[800,560]]]))
  assert.ok(corners?.strokes.length)
})
