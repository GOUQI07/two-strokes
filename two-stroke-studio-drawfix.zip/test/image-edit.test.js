import {test} from 'node:test'
import assert from 'node:assert/strict'
import sharp from 'sharp'
import {createDoodleEdit, DEFAULT_IMAGE_MODEL} from '../server/image-edit.js'

const original = [
  {c: '#423d4b', p: [[100, 110], [120, 110], [140, 110]]},
  {c: '#ef7294', p: [[250, 200]]}
]
const asEditCoord = n => Math.round(n * 1.8)
const rgbAt = (result, x, y) => {
  const start = (y * result.width + x) * result.channels
  return Array.from(result.pixels.subarray(start, start + 3))
}

test('makes one masked image edit, round-trips registration, and returns only cropped RGB data', async () => {
  let calls = 0
  const originalCopy = structuredClone(original)
  const fetchImpl = async (url, options) => {
    calls++
    assert.equal(url, 'https://api.openai.com/v1/images/edits')
    assert.equal(options.method, 'POST')
    assert.equal(options.redirect, 'error')
    assert.equal(options.headers.Authorization, 'Bearer sample')
    assert.equal(options.body.get('model'), DEFAULT_IMAGE_MODEL)
    assert.equal(options.body.get('n'), '1')
    assert.equal(options.body.get('quality'), 'high')
    const input = Buffer.from(await options.body.get('image').arrayBuffer())
    const mask = await sharp(Buffer.from(await options.body.get('mask').arrayBuffer())).raw().toBuffer({resolveWithObject: true})
    assert.equal(mask.info.channels, 4)
    const maskAlpha = (x, y) => mask.data[(mask.info.width * y + x) * 4 + 3]
    assert.equal(maskAlpha(0, 0), 255)
    assert.equal(maskAlpha(48 + asEditCoord(120), 8 + asEditCoord(110)), 255)
    assert.equal(maskAlpha(500, 500), 0)
    assert.equal(maskAlpha(48 + asEditCoord(250), 8 + asEditCoord(200)), 255)

    // Draw a black square at the model-space position of logical pixel (320,250).
    const square = await sharp({create: {width: 12, height: 12, channels: 3, background: 'black'}}).png().toBuffer()
    const edited = await sharp(input).composite([{
      input: square, left: 48 + asEditCoord(320) - 6, top: 8 + asEditCoord(250) - 6
    }]).png().toBuffer()
    return Response.json({data: [{b64_json: edited.toString('base64')}]})
  }
  const result = await createDoodleEdit(original, {apiKey:'sample', model:DEFAULT_IMAGE_MODEL, fetchImpl})
  assert.deepEqual(original, originalCopy)
  assert.equal(calls, 1)
  assert.deepEqual([result.width, result.height, result.channels], [800, 560, 3])
  assert.ok(rgbAt(result, 120, 110).every((v, i) => Math.abs(v - [22, 131, 232][i]) < 6))
  assert.deepEqual(rgbAt(result, 320, 250), [0, 0, 0])
  assert.deepEqual(rgbAt(result, 450, 400), [255, 255, 255])
})

test('handles missing access without retrying or exposing the upstream payload', async () => {
  let calls = 0
  await assert.rejects(createDoodleEdit(original, {
    apiKey: 'sample',
    fetchImpl: async () => {
      calls++
      return Response.json({error: {code:'model_not_found', message:'example private provider data'}}, {status:404})
    }
  }), error => error.status === 503 && !error.message.includes('private provider data'))
  assert.equal(calls, 1)
})

test('stops before the paid request when caller has cancelled', async () => {
  const controller = new AbortController()
  controller.abort()
  let calls = 0
  await assert.rejects(createDoodleEdit(original, {
    apiKey:'sample', signal:controller.signal, fetchImpl:async()=>{calls++}
  }), {name:'AbortError'})
  assert.equal(calls, 0)
})
