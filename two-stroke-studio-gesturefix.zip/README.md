# 两笔挑战 — 手机可玩的双人 AI 简笔画接力

这是一个 **Vue 3 + Vite + Node.js Express + OpenAI Responses API** 项目。

- 用手指画 **恰好两笔**；原始笔画保留在独立图层，程序永远不会让 AI 修改它们。
- 演示模式无须 API Key（仅预设新增笔画，不能理解涂鸦）。
- AI 模式将两笔的坐标发给 OpenAI，让模型只输出**新增笔画的坐标**，再由 Canvas 按画笔速度逐笔动画画出来。
- 支持撤销、重画、回放、变速、暂停、导出 PNG。

## 只有手机怎么用（推荐）

**体验演示（无需部署、无需密钥）**：下载并解压 ZIP，尝试在手机浏览器打开 `demo/手机试玩版.html`。部分 Android 浏览器不允许直接打开本地 HTML：可使用支持本地 HTML 的文件浏览器，或先部署正式站点后直接访问网址。

**用手机部署正式网站**：所有需要运行的 Node.js、Vue.js 都在云服务器上，手机无需安装。

1. 用手机浏览器注册 [GitHub](https://github.com) 和 [Render](https://dashboard.render.com)。
2. 在 GitHub 创建一个空仓库（例如 `two-stroke-studio`），解压项目压缩包，将仓库根目录的项目文件上传到仓库中。GitHub 手机网页的 `Add file → Upload files` 可以上传单个文件；**GitHub 网页不一定支持直接上传整个文件夹**，如果手机上批量上传不方便，可以使用支持 Git 的手机应用，或连接 GitHub 插件来协助。
3. 在 Render 选择 `New → Web Service`，连接 GitHub 仓库。使用以下设置：
   - Build Command: `npm install && npm run build`
   - Start Command: `npm start`
   - Node.js 运行时，Free 或自己选择的套餐。
4. Render 的 Environment 添加 `OPENAI_API_KEY`，值填写你在 [OpenAI API Keys](https://platform.openai.com/api-keys) 创建的 Key。**不要把 Key 直接贴给别人、写入 GitHub 或网页。**
5. 可选：添加 `GAME_ACCESS_CODE`，自选一段访问口令；网站中切换到 AI 模式后填写这段口令。强烈建议公开部署时设置访问码，以免陌生人反复调用产生 API 费用。
6. Render 构建、部署成功后会产生一个 `https://...onrender.com` 网址。直接用手机浏览器打开它即可开始玩。需要注意 OpenAI API 按调用计费，ChatGPT 订阅并不等于 API 额度。

> 以上部署流程依赖你自己的 GitHub/Render 账号、OpenAI API Key、可访问的网络和平台当时的服务状态。**当前交付的是项目文件，并不是已经上线的网址。**

## 已有电脑的可选开发方式

要求 Node.js 20 或更高。

```bash
npm install
cp .env.example .env
# 修改 .env 中的 OPENAI_API_KEY
npm run build
npm start
```

打开 `http://localhost:3000`。开发模式用两个终端分别运行 `npm run dev:server` 和 `npm run dev`。

## 安全与技术边界

- 用户的两笔在 Canvas 的第一层绘制；AI 只能输出第二层新增笔画的坐标。
- 后端对用户笔画、AI 响应、画布边界和点数量做校验，API Key 始终留在服务端。
- 自带按 IP 简单限频（单实例有效；大流量公开站点建议使用 Redis 级别限流、账户鉴权、每日额度限制）。
- AI 只收到坐标、线条颜色，不直接看到真实图片；对任意线条的理解、趣味和美观不能保证，需要多轮调优模型提示词。
- 无 Key 演示只用于验证玩法和绘画动画，不等于 AI 创造效果。在线部署的网站需要流量可访问 OpenAI API。

## 环境变量

| 名称 | 说明 |
| --- | --- |
| OPENAI_API_KEY | OpenAI API Key，正式 AI 补画必填 |
| OPENAI_MODEL | 默认为 `gpt-4.1-mini` |
| GAME_ACCESS_CODE | 可选，公开站点建议设置 |
| PORT | 云服务器端口，默认 3000 |


### 手机触屏修复版
使用非 passive 的原生 Touch Events 接收连续滑动，触摸移动时阻止浏览器滚动；触控取消不会被算作一笔。鼠标与触控笔沿用 Pointer Events。部署后建议手机浏览器刷新页面再测试。
